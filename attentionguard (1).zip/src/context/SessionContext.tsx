import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  AppView,
  AttentionCheck,
  ClassroomMessage,
  CueType,
  ResponseRecord,
  Session,
  Student,
  StudentActiveCheck,
  VerificationScheduleMode,
} from '../types';
import {
  INITIAL_CLASSROOM_MESSAGES,
  INITIAL_PAST_CHECKS,
  INITIAL_SESSION,
  INITIAL_STUDENTS,
} from '../data/mockData';
import { playAttentionCue, playConfirmationSound } from '../utils/audio';
import { calculateStudentScore, categorizeResponseTime } from '../utils/scoring';
import { generateNextCheckDelay } from '../utils/scheduling';

interface SessionContextType {
  currentView: AppView;
  setCurrentView: (view: AppView) => void;
  session: Session;
  students: Student[];
  pastChecks: AttentionCheck[];
  selectedStudentId: string;
  setSelectedStudentId: (id: string) => void;
  volume: number;
  setVolume: (v: number) => void;
  soundEnabled: boolean;
  setSoundEnabled: (v: boolean) => void;
  selectedCueType: CueType;
  setSelectedCueType: (t: CueType) => void;

  // Independent Student Attention Verification
  scheduleMode: VerificationScheduleMode;
  setScheduleMode: (mode: VerificationScheduleMode) => void;
  currentStudentActiveCheck: StudentActiveCheck | null;
  activeCheck: StudentActiveCheck | null;
  checkTimeRemaining: number;
  hasStudentResponded: boolean;
  studentResponseTime: number | null;

  // Actions
  triggerAttentionCheck: (targetStudentId?: string, customCue?: CueType) => void;
  triggerAllStaggeredChecks: () => void;
  handleStudentResponse: (studentId?: string, customTime?: number) => void;
  simulateDemoScenario: (scenario: 'quick' | 'delayed' | 'missed') => void;
  startSession: () => void;
  endSession: () => void;
  resetDemoData: () => void;
  testAudioCue: (type?: CueType) => void;
  updateClassSession: (params: { title: string; courseCode?: string; teacherName?: string }) => void;
  classroomMessages: ClassroomMessage[];
  sendClassroomMessage: (text: string, sender?: string, role?: 'teacher' | 'student') => void;
}

const VALID_VIEWS: AppView[] = [
  'home',
  'classroom',
  'teacher',
  'student',
  'live-demo',
  'how-it-works',
  'privacy',
  'about',
];

const getViewFromHash = (): AppView => {
  if (typeof window === 'undefined') return 'home';
  const raw = window.location.hash.replace(/^#\/?/, '').trim() as AppView;
  return VALID_VIEWS.includes(raw) ? raw : 'home';
};

const SessionContext = createContext<SessionContextType | undefined>(undefined);

export const SessionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentViewState] = useState<AppView>(() => getViewFromHash());

  const setCurrentView = useCallback((view: AppView) => {
    setCurrentViewState(view);
    if (typeof window !== 'undefined') {
      const targetHash = view === 'home' ? '' : `#${view}`;
      if (window.location.hash !== targetHash) {
        window.history.replaceState(null, '', targetHash || window.location.pathname);
      }
    }
  }, []);

  useEffect(() => {
    const handleHash = () => {
      const view = getViewFromHash();
      setCurrentViewState(view);
    };
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);
  const [session, setSession] = useState<Session>(() => {
    const saved = localStorage.getItem('ag_session');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return {
          ...INITIAL_SESSION,
          ...parsed,
          scheduleMode: parsed.scheduleMode || 'demo',
        };
      } catch {
        return INITIAL_SESSION;
      }
    }
    return INITIAL_SESSION;
  });

  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem('ag_students');
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as Student[];
        // Ensure each student has independent scheduling properties
        return parsed.map((s, idx) => ({
          ...s,
          nextCheckTimestamp: s.nextCheckTimestamp || (Date.now() + 10000 + idx * 3000),
          activeCheck: null, // start with clean active check
        }));
      } catch {
        return INITIAL_STUDENTS;
      }
    }
    return INITIAL_STUDENTS;
  });

  const [pastChecks, setPastChecks] = useState<AttentionCheck[]>(() => {
    const saved = localStorage.getItem('ag_checks');
    return saved ? JSON.parse(saved) : INITIAL_PAST_CHECKS;
  });

  const [classroomMessages, setClassroomMessages] = useState<ClassroomMessage[]>(() => {
    const saved = localStorage.getItem('ag_messages');
    return saved ? JSON.parse(saved) : INITIAL_CLASSROOM_MESSAGES;
  });

  const [selectedStudentId, setSelectedStudentId] = useState<string>('stu-1'); // Arun Kumar
  const [volume, setVolume] = useState<number>(0.65);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [selectedCueType, setSelectedCueType] = useState<CueType>('gentle_chime');
  const [hasStudentResponded, setHasStudentResponded] = useState<boolean>(false);
  const [studentResponseTime, setStudentResponseTime] = useState<number | null>(null);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('ag_session', JSON.stringify(session));
  }, [session]);

  useEffect(() => {
    localStorage.setItem('ag_students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('ag_checks', JSON.stringify(pastChecks));
  }, [pastChecks]);

  useEffect(() => {
    localStorage.setItem('ag_messages', JSON.stringify(classroomMessages));
  }, [classroomMessages]);

  // Current selected student's active check
  const currentStudent = students.find((s) => s.id === selectedStudentId);
  const currentStudentActiveCheck = currentStudent?.activeCheck || null;

  // Countdown timer for the currently selected student
  const [checkTimeRemaining, setCheckTimeRemaining] = useState<number>(8);
  useEffect(() => {
    if (!currentStudentActiveCheck) {
      setCheckTimeRemaining(8);
      setHasStudentResponded(false);
      return;
    }

    const interval = setInterval(() => {
      const elapsedSec = (Date.now() - currentStudentActiveCheck.startTime) / 1000;
      const rem = Math.max(0, currentStudentActiveCheck.timeoutSeconds - elapsedSec);
      setCheckTimeRemaining(Number(rem.toFixed(1)));
    }, 100);

    return () => clearInterval(interval);
  }, [currentStudentActiveCheck]);

  // Schedule mode updater
  const setScheduleMode = useCallback((mode: VerificationScheduleMode) => {
    setSession((prev) => ({ ...prev, scheduleMode: mode }));
    // Re-jitter all pending students so new intervals apply immediately
    const now = Date.now();
    setStudents((prev) =>
      prev.map((s, idx) => ({
        ...s,
        nextCheckTimestamp: s.activeCheck
          ? s.nextCheckTimestamp
          : now + generateNextCheckDelay(mode) + (idx * (mode === 'demo' ? 1500 : 8000)),
      }))
    );
  }, []);

  // Audio test helper
  const testAudioCue = useCallback(
    (type?: CueType) => {
      if (soundEnabled) {
        playAttentionCue(type || selectedCueType, volume);
      }
    },
    [soundEnabled, selectedCueType, volume]
  );

  // Trigger an attention check for a specific student (or current student if omitted)
  const triggerAttentionCheck = useCallback(
    (targetStudentId?: string, customCue?: CueType) => {
      if (!session.isActive) return;

      const studentIdToTrigger = targetStudentId || selectedStudentId;
      const now = Date.now();
      const cue = customCue || selectedCueType;
      const checkId = 'chk-' + studentIdToTrigger + '-' + now.toString().slice(-5);

      setStudents((prev) =>
        prev.map((stu) => {
          if (stu.id === studentIdToTrigger) {
            // Play audio ONLY if this student is the one actively logged in
            if (stu.id === selectedStudentId && soundEnabled) {
              playAttentionCue(cue, volume);
            }
            return {
              ...stu,
              activeCheck: {
                id: checkId,
                startTime: now,
                timeoutSeconds: 8,
                cueType: cue,
              },
              lastResponseStatus: 'pending',
            };
          }
          return stu;
        })
      );

      if (studentIdToTrigger === selectedStudentId) {
        setHasStudentResponded(false);
        setStudentResponseTime(null);
      }
    },
    [session.isActive, selectedStudentId, selectedCueType, soundEnabled, volume]
  );

  // Staggered attention checks: schedules all students with independent random offsets in the near future
  const triggerAllStaggeredChecks = useCallback(() => {
    if (!session.isActive) return;
    const now = Date.now();
    setStudents((prev) =>
      prev.map((stu, idx) => ({
        ...stu,
        // Each student gets their own independent staggered time
        nextCheckTimestamp: now + 2000 + (idx * 2500) + Math.random() * 2000,
      }))
    );
  }, [session.isActive]);

  // Handle student response (for current user persona or specific student)
  const handleStudentResponse = useCallback(
    (studentId?: string, customTime?: number) => {
      const targetId = studentId || selectedStudentId;
      const now = Date.now();

      setStudents((prev) =>
        prev.map((stu) => {
          if (stu.id === targetId && stu.activeCheck) {
            const elapsed =
              customTime !== undefined
                ? customTime
                : Number(((now - stu.activeCheck.startTime) / 1000).toFixed(2));

            const finalTime = Math.min(Math.max(0.4, elapsed), stu.activeCheck.timeoutSeconds);
            const speedCat = categorizeResponseTime(finalTime);

            if (stu.id === selectedStudentId) {
              playConfirmationSound();
              setStudentResponseTime(finalTime);
              setHasStudentResponded(true);
            }

            const newRecord: ResponseRecord = {
              id: 'resp-' + stu.id + '-' + now,
              checkId: stu.activeCheck.id,
              studentId: stu.id,
              responseTime: finalTime,
              status: speedCat,
              timestamp: now,
            };

            const newHistory = [...stu.history, newRecord];
            const calculated = calculateStudentScore(newHistory);

            return {
              ...stu,
              activeCheck: null,
              lastResponseStatus: (finalTime <= 5.0 ? 'responded' : 'delayed') as 'responded' | 'delayed',
              lastResponseTime: finalTime,
              attentionScore: calculated.score,
              currentStatus: calculated.status,
              responseCount: stu.responseCount + 1,
              totalChecks: stu.totalChecks + 1,
              history: newHistory,
              // Schedule next independent check for THIS student
              nextCheckTimestamp: now + generateNextCheckDelay(session.scheduleMode),
            };
          }
          return stu;
        })
      );
    },
    [selectedStudentId, session.scheduleMode]
  );

  // Independent student scheduler loop
  useEffect(() => {
    if (!session.isActive) return;

    const interval = setInterval(() => {
      const now = Date.now();

      setStudents((prevStudents) => {
        let changed = false;

        const nextStudents = prevStudents.map((student) => {
          // Case 1: Student has an active attention check currently running
          if (student.activeCheck) {
            const elapsedMs = now - student.activeCheck.startTime;
            const timeoutMs = student.activeCheck.timeoutSeconds * 1000;

            // For background simulated students (not the current user):
            if (student.id !== selectedStudentId) {
              // Natural latency distribution
              const simulateLatencyMs =
                student.currentStatus === 'attentive'
                  ? 1200 + Math.random() * 1200
                  : student.currentStatus === 'active'
                  ? 2000 + Math.random() * 2000
                  : 4500 + Math.random() * 3500;

              const isSimulatedMiss = student.currentStatus === 'needs_attention' && Math.random() < 0.2;

              if (!isSimulatedMiss && elapsedMs >= simulateLatencyMs) {
                // Background student responds independently!
                changed = true;
                const respSec = Number((simulateLatencyMs / 1000).toFixed(2));
                const cat = categorizeResponseTime(respSec);

                const record: ResponseRecord = {
                  id: 'resp-' + student.id + '-' + now,
                  checkId: student.activeCheck.id,
                  studentId: student.id,
                  responseTime: respSec,
                  status: cat,
                  timestamp: now,
                };

                const newHistory = [...student.history, record];
                const calc = calculateStudentScore(newHistory);

                return {
                  ...student,
                  activeCheck: null,
                  lastResponseStatus: (respSec <= 5.0 ? 'responded' : 'delayed') as 'responded' | 'delayed',
                  lastResponseTime: respSec,
                  attentionScore: calc.score,
                  currentStatus: calc.status,
                  responseCount: student.responseCount + 1,
                  totalChecks: student.totalChecks + 1,
                  history: newHistory,
                  nextCheckTimestamp: now + generateNextCheckDelay(session.scheduleMode),
                };
              }
            }

            // Check if timed out
            if (elapsedMs >= timeoutMs) {
              changed = true;
              const record: ResponseRecord = {
                id: 'resp-' + student.id + '-' + now,
                checkId: student.activeCheck.id,
                studentId: student.id,
                responseTime: null,
                status: 'missed',
                timestamp: now,
              };

              const newHistory = [...student.history, record];
              const calc = calculateStudentScore(newHistory);

              return {
                ...student,
                activeCheck: null,
                lastResponseStatus: 'missed' as const,
                lastResponseTime: null,
                attentionScore: calc.score,
                currentStatus: calc.status,
                missedCount: student.missedCount + 1,
                totalChecks: student.totalChecks + 1,
                history: newHistory,
                nextCheckTimestamp: now + generateNextCheckDelay(session.scheduleMode),
              };
            }

            return student;
          }

          // Case 2: Student has no active check — check if their independent timer has arrived
          if (now >= student.nextCheckTimestamp) {
            changed = true;
            const newCheckId = 'chk-' + student.id + '-' + now.toString().slice(-5);
            const cueType = session.cueType;

            // CRITICAL: Play chime ONLY for the student currently active in view!
            if (student.id === selectedStudentId && soundEnabled) {
              playAttentionCue(cueType, volume);
            }

            return {
              ...student,
              activeCheck: {
                id: newCheckId,
                startTime: now,
                timeoutSeconds: 8,
                cueType,
              },
              lastResponseStatus: 'pending' as const,
            };
          }

          return student;
        });

        return changed ? nextStudents : prevStudents;
      });
    }, 500);

    return () => clearInterval(interval);
  }, [
    session.isActive,
    session.scheduleMode,
    session.cueType,
    selectedStudentId,
    soundEnabled,
    volume,
  ]);

  // Demo shortcut simulators for the active persona
  const simulateDemoScenario = useCallback(
    (scenario: 'quick' | 'delayed' | 'missed') => {
      if (scenario === 'quick') {
        triggerAttentionCheck(selectedStudentId);
        setTimeout(() => handleStudentResponse(selectedStudentId, 1.2), 300);
      } else if (scenario === 'delayed') {
        triggerAttentionCheck(selectedStudentId);
        setTimeout(() => handleStudentResponse(selectedStudentId, 6.4), 300);
      } else {
        // Missed (instant timeout simulation)
        const now = Date.now();
        setStudents((prev) =>
          prev.map((s) => {
            if (s.id === selectedStudentId) {
              const record: ResponseRecord = {
                id: 'resp-' + s.id + '-' + now,
                checkId: 'chk-missed-' + now,
                studentId: s.id,
                responseTime: null,
                status: 'missed',
                timestamp: now,
              };
              const newHistory = [...s.history, record];
              const calc = calculateStudentScore(newHistory);
              return {
                ...s,
                activeCheck: null,
                lastResponseStatus: 'missed' as const,
                lastResponseTime: null,
                attentionScore: calc.score,
                currentStatus: calc.status,
                missedCount: s.missedCount + 1,
                totalChecks: s.totalChecks + 1,
                history: newHistory,
                nextCheckTimestamp: now + generateNextCheckDelay(session.scheduleMode),
              };
            }
            return s;
          })
        );
      }
    },
    [selectedStudentId, triggerAttentionCheck, handleStudentResponse, session.scheduleMode]
  );

  // Global session start/stop
  const startSession = () => {
    const now = Date.now();
    setSession((prev) => ({
      ...prev,
      isActive: true,
      startTime: now,
    }));
    // Re-initialize all independent student schedules with staggered delays
    setStudents((prev) =>
      prev.map((s, idx) => ({
        ...s,
        activeCheck: null,
        nextCheckTimestamp: now + 8000 + (idx * (session.scheduleMode === 'demo' ? 1800 : 9000)),
      }))
    );
  };

  const endSession = () => {
    setSession((prev) => ({
      ...prev,
      isActive: false,
    }));
    setStudents((prev) =>
      prev.map((s) => ({
        ...s,
        activeCheck: null,
      }))
    );
  };

  const resetDemoData = () => {
    localStorage.removeItem('ag_session');
    localStorage.removeItem('ag_students');
    localStorage.removeItem('ag_checks');
    localStorage.removeItem('ag_messages');
    setSession(INITIAL_SESSION);
    setStudents(INITIAL_STUDENTS);
    setPastChecks(INITIAL_PAST_CHECKS);
    setClassroomMessages(INITIAL_CLASSROOM_MESSAGES);
    setHasStudentResponded(false);
    setStudentResponseTime(null);
  };

  const sendClassroomMessage = useCallback(
    (text: string, sender?: string, role: 'teacher' | 'student' = 'student') => {
      if (!text.trim()) return;
      const student = students.find((s) => s.id === selectedStudentId);
      const authorName =
        sender || (role === 'teacher' ? session.teacherName : student?.name || 'Student');

      const newMsg: ClassroomMessage = {
        id: 'msg-' + Date.now(),
        sender: authorName,
        role,
        text: text.trim(),
        timestamp: Date.now(),
      };

      setClassroomMessages((prev) => [...prev, newMsg]);
    },
    [session.teacherName, selectedStudentId, students]
  );

  const updateClassSession = useCallback(
    (params: { title: string; courseCode?: string; teacherName?: string }) => {
      setSession((prev) => ({
        ...prev,
        title: params.title.trim() || prev.title,
        courseCode: params.courseCode?.trim() || prev.courseCode,
        teacherName: params.teacherName?.trim() || prev.teacherName,
      }));
    },
    []
  );

  // Keyboard shortcut listener: Space or Enter responds to active check
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if typing in an input or textarea
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return;

      if ((e.code === 'Space' || e.code === 'Enter') && currentStudentActiveCheck && !hasStudentResponded) {
        e.preventDefault();
        handleStudentResponse();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentStudentActiveCheck, hasStudentResponded, handleStudentResponse]);

  return (
    <SessionContext.Provider
      value={{
        currentView,
        setCurrentView,
        session,
        students,
        pastChecks,
        selectedStudentId,
        setSelectedStudentId,
        volume,
        setVolume,
        soundEnabled,
        setSoundEnabled,
        selectedCueType,
        setSelectedCueType,
        scheduleMode: session.scheduleMode,
        setScheduleMode,
        currentStudentActiveCheck,
        activeCheck: currentStudentActiveCheck,
        checkTimeRemaining,
        hasStudentResponded,
        studentResponseTime,
        triggerAttentionCheck,
        triggerAllStaggeredChecks,
        handleStudentResponse,
        simulateDemoScenario,
        startSession,
        endSession,
        resetDemoData,
        testAudioCue,
        updateClassSession,
        classroomMessages,
        sendClassroomMessage,
      }}
    >
      {children}
    </SessionContext.Provider>
  );
};

export const useSession = () => {
  const context = useContext(SessionContext);
  if (!context) {
    throw new Error('useSession must be used within a SessionProvider');
  }
  return context;
};
