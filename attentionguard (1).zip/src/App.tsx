/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { SessionProvider, useSession } from './context/SessionContext';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { HeroSection } from './components/home/HeroSection';
import { FeatureCards } from './components/home/FeatureCards';
import { ProcessFlow } from './components/home/ProcessFlow';
import { TeacherDashboard } from './components/teacher/TeacherDashboard';
import { StudentView } from './components/student/StudentView';
import { LiveDemoPage } from './components/demo/LiveDemoPage';
import { PrivacyPage } from './components/privacy/PrivacyPage';
import { HowItWorksPage } from './components/howitworks/HowItWorksPage';
import { AboutPage } from './components/about/AboutPage';
import { OnlineClassroom } from './components/classroom/OnlineClassroom';

const MainContent: React.FC = () => {
  const { currentView } = useSession();

  return (
    <main className="min-h-screen">
      {currentView === 'home' && (
        <>
          <HeroSection />
          <ProcessFlow />
          <FeatureCards />
        </>
      )}

      {currentView === 'classroom' && <OnlineClassroom />}

      {currentView === 'how-it-works' && <HowItWorksPage />}

      {currentView === 'teacher' && <TeacherDashboard />}

      {currentView === 'student' && <StudentView />}

      {currentView === 'live-demo' && <LiveDemoPage />}

      {currentView === 'privacy' && <PrivacyPage />}

      {currentView === 'about' && <AboutPage />}
    </main>
  );
};

export default function App() {
  return (
    <SessionProvider>
      <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100 antialiased font-sans selection:bg-indigo-500/30 selection:text-indigo-200">
        <Navbar />
        <div className="flex-1">
          <MainContent />
        </div>
        <Footer />
      </div>
    </SessionProvider>
  );
}
