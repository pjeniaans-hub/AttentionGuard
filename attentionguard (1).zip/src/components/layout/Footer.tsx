import React from 'react';
import { useSession } from '../../context/SessionContext';
import { AppView } from '../../types';
import { Shield, EyeOff, VideoOff, Lock, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  const { setCurrentView } = useSession();

  const handleNav = (v: AppView) => {
    setCurrentView(v);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="border-t border-slate-800/80 bg-slate-950 text-slate-400">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Brand info */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-md bg-indigo-600 text-white">
                <Shield className="h-4 w-4" />
              </div>
              <span className="text-base font-bold text-white tracking-tight">AttentionGuard</span>
            </div>
            <p className="text-sm text-slate-400 max-w-md leading-relaxed">
              Privacy-friendly, non-camera-based Attention Verification System for online classrooms and remote meetings. Eliminating invasive video surveillance while giving educators reliable presence insight.
            </p>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-2 pt-1 text-xs text-slate-400">
              <span className="flex items-center gap-1.5 text-emerald-400">
                <EyeOff className="h-3.5 w-3.5" /> No Facial Tracking
              </span>
              <span className="flex items-center gap-1.5 text-emerald-400">
                <VideoOff className="h-3.5 w-3.5" /> Zero Camera Access
              </span>
              <span className="flex items-center gap-1.5 text-emerald-400">
                <Lock className="h-3.5 w-3.5" /> Biometric-Free
              </span>
            </div>
          </div>

          {/* Navigation Links */}
          <div>
            <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">Navigation</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => handleNav('home')} className="hover:text-white transition-colors">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('classroom')} className="hover:text-white transition-colors">
                  Online Classroom
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('teacher')} className="hover:text-white transition-colors">
                  Teacher Dashboard
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('student')} className="hover:text-white transition-colors">
                  Student View
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('live-demo')} className="hover:text-white transition-colors">
                  Interactive Live Demo
                </button>
              </li>
            </ul>
          </div>

          {/* Ethics & Compliance */}
          <div>
            <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">Ethics & Policies</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => handleNav('privacy')} className="hover:text-white transition-colors">
                  Privacy Architecture
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('about')} className="hover:text-white transition-colors">
                  Non-Invasive Manifesto
                </button>
              </li>
              <li>
                <a
                  href="#privacy-guarantee"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNav('privacy');
                  }}
                  className="hover:text-white transition-colors"
                >
                  Zero Video Commitment
                </a>
              </li>
              <li>
                <span className="text-xs text-slate-400 block pt-1">
                  Built for College Hackathon Showcase
                </span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-800/60 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm font-medium text-slate-300">
            AttentionGuard — Verify participation. Respect privacy.
          </p>
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span>Engineered with integrity</span>
            <Heart className="h-3 w-3 text-rose-500 fill-rose-500" />
            <span>for equitable education</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
