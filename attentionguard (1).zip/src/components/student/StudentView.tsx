import React, { useState, useEffect } from 'react';
import { useSession } from '../../context/SessionContext';
import {
  Headphones,
  Volume2,
  ShieldCheck,
  Check,
  Clock,
  EyeOff,
  User,
  BookOpen,
  ArrowRight,
  Zap,
} from 'lucide-react';
import { formatCountdown } from '../../utils/scheduling';

export const StudentView: React.FC = () => {
  const {
    session,
    currentStudentActiveCheck,
    checkTimeRemaining,
    hasStudentResponded,
    studentResponseTime,
    handleStudentResponse,
    testAudioCue,
    students,
    selectedStudentId,
    setSelectedStudentId,
    triggerAttentionCheck,
    scheduleMode,
    setCurrentView,
  } = useSession();

  const [showScoreSummary, setShowScoreSummary] = useState(false);
  const [, setTick] = useState(0);

  // Live tick to keep the student's next-check countdown synchronized
  useEffect(() => {
    const timer = setInterval(() => setTick((t) => t + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  const currentStudent = students.find(s => s.id === selectedStudentId) || students[0];

  return (
    <div className="min-h-[85vh] bg-slate-950 flex flex-col items-center justify-center py-10 px-4 sm:px-6">
      <div className="w-full max-w-2xl space-y-6">
        {/* Top Header Card: Class Info & Connected Status */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-6 shadow-xl backdrop-blur-sm">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-800 pb-5">
            <div>
              <div className="text-xs font-semibold uppercase tracking-wider text-indigo-400 mb-1">
                Online Classroom
              </div>
              <h1 className="text-xl sm:text-2xl font-bold text-white">
                Online Class: {session.title}
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
                Teacher: <span className="text-slate-200 font-medium">{session.teacherName}</span>
              </p>
            </div>

            {/* Connection and Privacy Status Badges */}
            <div className="flex flex-col sm:items-end gap-1.5">
              <div className="inline-flex items-center gap-2 text-xs font-medium text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-3 py-1 rounded-full">
                <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Connected</span>
              </div>
              <div className="inline-flex items-center gap-1.5 text-xs text-indigo-300">
                <Headphones className="h-3.5 w-3.5 text-indigo-400" />
                <span>Attention Verification Active</span>
              </div>
            </div>
          </div>

          {/* Student Persona Switcher & Audio Tester */}
          <div className="pt-4 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <User className="h-3.5 w-3.5 text-slate-400" />
              <span className="text-slate-400">Logged In As:</span>
              <select
                value={selectedStudentId}
                onChange={(e) => setSelectedStudentId(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-md px-2.5 py-1 text-slate-200 font-medium focus:outline-none focus:border-indigo-500"
              >
                {students.map(s => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.email.split('@')[0]})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => testAudioCue()}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-indigo-300 transition-colors border border-slate-700 font-medium"
              >
                <Volume2 className="h-3.5 w-3.5" />
                <span>Test Audio Cue</span>
              </button>
            </div>
          </div>
        </div>

        {/* Enter Built-In Online Classroom Banner */}
        <div className="rounded-2xl border border-indigo-900/50 bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 p-5 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center shrink-0">
              <BookOpen className="h-5 w-5" />
            </div>
            <div>
              <div className="text-sm font-bold text-white">Join Interactive Lecture & Discussion</div>
              <div className="text-xs text-slate-400">View whiteboard slides, ask questions, and follow along</div>
            </div>
          </div>

          <button
            onClick={() => setCurrentView('classroom')}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md transition-all active:scale-95 whitespace-nowrap"
          >
            <span>Enter Live Classroom</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        {/* Core Verification Card */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-8 shadow-2xl relative overflow-hidden text-center min-h-[320px] flex flex-col items-center justify-center">
          {/* Subtle Ambient Glow */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-indigo-600/10 rounded-full blur-[80px] pointer-events-none" />

          {currentStudentActiveCheck ? (
            /* Attention Check is ACTIVE for THIS student */
            !hasStudentResponded ? (
              <div className="w-full max-w-md space-y-6 relative z-10 animate-in zoom-in-95 duration-200">
                {/* Visual pulse indicator */}
                <div className="relative mx-auto w-20 h-20 flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full bg-indigo-500/20 animate-ping" />
                  <div className="h-16 w-16 rounded-full bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/40">
                    <Headphones className="h-8 w-8 animate-bounce" />
                  </div>
                </div>

                <div>
                  <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                    Attention Check — Respond Now
                  </h2>
                  <p className="text-base text-indigo-200 mt-1">
                    Please respond now
                  </p>
                  <div className="text-xs text-slate-400 mt-2 font-mono tabular-nums">
                    Auto-expires in {checkTimeRemaining} seconds
                  </div>
                </div>

                {/* Response Buttons */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <button
                    onClick={() => handleStudentResponse()}
                    className="w-full py-4 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 transition-all active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400 animate-pulse"
                  >
                    I'm Listening (SPACE)
                  </button>

                  <button
                    onClick={() => handleStudentResponse()}
                    className="w-full py-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-200 font-semibold text-sm border border-slate-700 transition-all active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400"
                  >
                    Respond
                  </button>
                </div>

                {/* Keyboard Hint */}
                <div className="text-xs text-slate-400 flex items-center justify-center gap-2">
                  <span>Or press</span>
                  <kbd className="px-2 py-1 rounded bg-slate-800 border border-slate-700 text-slate-200 font-mono text-[11px] shadow-sm">
                    SPACE
                  </kbd>
                  <span>or</span>
                  <kbd className="px-2 py-1 rounded bg-slate-800 border border-slate-700 text-slate-200 font-mono text-[11px] shadow-sm">
                    ENTER
                  </kbd>
                </div>
              </div>
            ) : (
              /* Already Responded State */
              <div className="w-full max-w-md space-y-4 relative z-10 animate-in fade-in duration-300">
                <div className="mx-auto w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                  <Check className="h-8 w-8 stroke-[3]" />
                </div>

                <div className="space-y-1">
                  <h3 className="text-2xl font-bold text-white">
                    Response recorded ✓
                  </h3>
                  <p className="text-sm font-mono tabular-nums text-emerald-400 font-semibold">
                    Response time: {studentResponseTime !== null ? `${studentResponseTime.toFixed(1)} seconds` : '1.3 seconds'}
                  </p>
                  <p className="text-xs text-slate-400 pt-1">
                    Thank you. Your next independent cue will sound in approximately {scheduleMode === 'demo' ? '10–20 seconds' : '2 minutes'}.
                  </p>
                </div>
              </div>
            )
          ) : (
            /* Standby State with Independent Schedule Countdown */
            <div className="w-full max-w-md space-y-4 relative z-10">
              <div className="mx-auto w-16 h-16 rounded-2xl bg-slate-800/80 border border-slate-700/60 flex items-center justify-center text-indigo-400">
                <Headphones className="h-7 w-7" />
              </div>

              <div>
                <h3 className="text-lg font-bold text-white">
                  Listening for Your Attention Cue
                </h3>
                <p className="text-xs sm:text-sm text-slate-400 max-w-sm mx-auto mt-1 leading-relaxed">
                  Every student has their own independent timer. When your chime sounds, tap Spacebar or click Respond.
                </p>

                {/* Independent Schedule Countdown Indicator */}
                <div className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs">
                  <Clock className="h-3.5 w-3.5 text-indigo-400" />
                  <span className="text-slate-400">Next check for {currentStudent.name.split(' ')[0]}:</span>
                  <span className="font-mono font-bold text-indigo-300">
                    {formatCountdown(currentStudent.nextCheckTimestamp)}
                  </span>
                  <span className="text-[10px] text-slate-500 border-l border-slate-800 pl-2">
                    {scheduleMode === 'demo' ? 'Demo Mode (10–20s)' : 'Real Mode (~2m)'}
                  </span>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => triggerAttentionCheck(currentStudent.id)}
                  className="px-4 py-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-300 hover:text-white transition-colors"
                >
                  Simulate My Cue Now
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Student Privacy Assurance Notice */}
        <div className="rounded-xl border border-slate-800/90 bg-slate-900/40 p-4 text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <EyeOff className="h-4 w-4 text-emerald-400 shrink-0" />
            <span>
              <strong>Zero-Camera Guarantee:</strong> Your camera and microphone are never accessed by AttentionGuard. Only acoustic cue acknowledgments are verified.
            </span>
          </div>

          <button
            onClick={() => setShowScoreSummary(!showScoreSummary)}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-medium whitespace-nowrap underline underline-offset-2"
          >
            {showScoreSummary ? 'Hide My History' : 'View Session Participation'}
          </button>
        </div>

        {/* Optional Participation Log */}
        {showScoreSummary && (
          <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 space-y-3 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                Participation Summary ({currentStudent.name})
              </h4>
              <span className="text-xs font-mono text-emerald-400 font-semibold">
                Status: {currentStudent.currentStatus === 'attentive' ? 'Attentive' : currentStudent.currentStatus === 'active' ? 'Active' : 'Needs attention check'}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-3 text-xs text-center">
              <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
                <div className="text-slate-400 text-[11px]">Total Checks</div>
                <div className="font-mono text-base font-bold text-white">{currentStudent.totalChecks}</div>
              </div>
              <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
                <div className="text-slate-400 text-[11px]">Responded</div>
                <div className="font-mono text-base font-bold text-emerald-400">{currentStudent.responseCount}</div>
              </div>
              <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
                <div className="text-slate-400 text-[11px]">Avg Speed</div>
                <div className="font-mono text-base font-bold text-indigo-300">
                  {currentStudent.lastResponseTime !== null ? `${currentStudent.lastResponseTime.toFixed(1)}s` : '1.4s'}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
