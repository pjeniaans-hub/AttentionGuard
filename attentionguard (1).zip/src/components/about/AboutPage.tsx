import React from 'react';
import { useSession } from '../../context/SessionContext';
import {
  ShieldCheck,
  Heart,
  Code2,
  Cpu,
  Sparkles,
  Users,
  Compass,
  ArrowRight,
} from 'lucide-react';

export const AboutPage: React.FC = () => {
  const { setCurrentView } = useSession();

  return (
    <div className="min-h-screen bg-slate-950 py-12 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-4xl space-y-12">
        {/* Header */}
        <div className="text-center space-y-4 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-950/70 border border-indigo-800/60 text-xs font-semibold text-indigo-400">
            <Heart className="h-3.5 w-3.5 text-rose-400" />
            <span>Hackathon Project & Origin Story</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            Built To Protect Privacy & Dignity In Remote Education
          </h1>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            The story behind AttentionGuard: rethinking online classroom engagement without turning students' bedrooms into monitored spaces.
          </p>
        </div>

        {/* The Problem & The Solution */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/60 space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-rose-400">The Problem</div>
            <h3 className="text-lg font-bold text-white">The Flawed Webcam Paradigm</h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              When online classes surged, instructors lost the visual cues of a physical classroom. In response, schools mandated webcams. But video requirements caused massive bandwidth strain, exposed private living spaces, penalized students with shared bedrooms, and introduced severe anxiety — while still failing to verify if students were actually listening.
            </p>
          </div>

          <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/60 space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-emerald-400">Our Solution</div>
            <h3 className="text-lg font-bold text-white">Acoustic Micro-Interactions</h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              AttentionGuard introduces non-invasive presence verification through gentle harmonic audio cues delivered at unpredictable intervals. Students respond with a single spacebar tap. This eliminates video surveillance completely while giving teachers reliable presence data.
            </p>
          </div>
        </div>

        {/* Core Principles */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-6 md:p-8 space-y-6">
          <h2 className="text-xl font-bold text-white">Our 3 Core Ethical Tenets</h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
            <div className="space-y-2">
              <div className="h-8 w-8 rounded-lg bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
                <ShieldCheck className="h-4 w-4" />
              </div>
              <h4 className="text-sm font-bold text-white">01. Zero Webcams</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                We never request camera access or transmit video bits. Student living environments remain completely private.
              </p>
            </div>

            <div className="space-y-2">
              <div className="h-8 w-8 rounded-lg bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
                <Users className="h-4 w-4" />
              </div>
              <h4 className="text-sm font-bold text-white">02. Respectful Phrasing</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                We never label students as definitively "not listening." We use constructive terminology like "Did not respond" or "Needs attention check."
              </p>
            </div>

            <div className="space-y-2">
              <div className="h-8 w-8 rounded-lg bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
                <Compass className="h-4 w-4" />
              </div>
              <h4 className="text-sm font-bold text-white">03. Transparent Scoring</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Attention scores reflect interaction response latency, not black-box algorithmic guessing or emotional classification.
              </p>
            </div>
          </div>
        </div>

        {/* Technical Architecture */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-6 md:p-8 space-y-4">
          <div className="flex items-center gap-2">
            <Code2 className="h-5 w-5 text-indigo-400" />
            <h3 className="text-lg font-bold text-white">Architecture & Technology Stack</h3>
          </div>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Built as a modern, high-performance web application designed for seamless hackathon demonstrations:
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs pt-1">
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
              <div className="text-indigo-400 font-bold mb-0.5">Frontend</div>
              <div className="text-slate-300">React 19 & TypeScript</div>
            </div>
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
              <div className="text-indigo-400 font-bold mb-0.5">Styling</div>
              <div className="text-slate-300">Tailwind CSS v4</div>
            </div>
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
              <div className="text-indigo-400 font-bold mb-0.5">Audio Engine</div>
              <div className="text-slate-300">Web Audio API (Synthesized)</div>
            </div>
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
              <div className="text-indigo-400 font-bold mb-0.5">Data Layer</div>
              <div className="text-slate-300">Reactive State & Local Store</div>
            </div>
          </div>
        </div>

        {/* Presentation CTA Banner */}
        <div className="rounded-2xl border border-indigo-900/40 bg-gradient-to-r from-indigo-950/40 via-slate-900 to-indigo-950/40 p-8 text-center space-y-4">
          <h3 className="text-xl sm:text-2xl font-bold text-white">
            Ready To See AttentionGuard In Action?
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto">
            Experience our 2-minute live demo showing the complete loop from audio chime to teacher dashboard updates.
          </p>
          <div className="pt-2">
            <button
              onClick={() => setCurrentView('live-demo')}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-all shadow-lg shadow-indigo-600/30 active:scale-95"
            >
              <span>Launch Live Interactive Demo</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
