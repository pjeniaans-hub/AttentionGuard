import React, { useState, useEffect } from 'react';
import { useSession } from '../../context/SessionContext';
import {
  Play,
  Square,
  Volume2,
  Headphones,
  Users,
  MessageSquare,
  Send,
  Clock,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  BookOpen,
  EyeOff,
  User,
  Zap,
} from 'lucide-react';
import { CueType } from '../../types';
import { formatCountdown } from '../../utils/scheduling';

export const OnlineClassroom: React.FC = () => {
  const {
    session,
    students,
    currentStudentActiveCheck,
    activeCheck,
    checkTimeRemaining,
    hasStudentResponded,
    studentResponseTime,
    triggerAttentionCheck,
    triggerAllStaggeredChecks,
    handleStudentResponse,
    testAudioCue,
    startSession,
    endSession,
    selectedCueType,
    setSelectedCueType,
    scheduleMode,
    setScheduleMode,
    selectedStudentId,
    setSelectedStudentId,
    classroomMessages,
    sendClassroomMessage,
    setCurrentView,
  } = useSession();

  const [activeTab, setActiveTab] = useState<'roster' | 'chat'>('chat');
  const [chatInput, setChatInput] = useState('');
  const [userRole, setUserRole] = useState<'teacher' | 'student'>('student');
  const [elapsedTimer, setElapsedTimer] = useState<string>('00:35:00');

  // Live tick to keep the student's next-check countdown synchronized
  const [, setTick] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => setTick((t) => t + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  // Active student object
  const currentStudent = students.find((s) => s.id === selectedStudentId) || students[0];

  // Session elapsed timer calculation
  useEffect(() => {
    const updateTimer = () => {
      if (!session.isActive) return;
      const diffMs = Math.max(0, Date.now() - session.startTime);
      const totalSec = Math.floor(diffMs / 1000);
      const hours = Math.floor(totalSec / 3600);
      const minutes = Math.floor((totalSec % 3600) / 60);
      const seconds = totalSec % 60;

      const pad = (n: number) => n.toString().padStart(2, '0');
      if (hours > 0) {
        setElapsedTimer(`${pad(hours)}:${pad(minutes)}:${pad(seconds)}`);
      } else {
        setElapsedTimer(`${pad(minutes)}:${pad(seconds)}`);
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [session.startTime, session.isActive]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    if (userRole === 'teacher') {
      sendClassroomMessage(chatInput, session.teacherName, 'teacher');
    } else {
      sendClassroomMessage(chatInput, currentStudent.name, 'student');
    }
    setChatInput('');
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col">
      {/* Top Classroom Bar */}
      <header className="border-b border-slate-800 bg-slate-900/90 px-4 py-3 sm:px-6 sticky top-16 z-40 backdrop-blur-md">
        <div className="mx-auto max-w-7xl flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Class Title & Instructor Info */}
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center shrink-0">
              <BookOpen className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold text-white tracking-tight">
                  {session.title}
                </h1>
                <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-indigo-300 font-mono font-semibold">
                  {session.courseCode}
                </span>
              </div>
              <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                <span>Instructor: <strong className="text-slate-300">{session.teacherName}</strong></span>
                <span>·</span>
                <span className="flex items-center gap-1 text-emerald-400 font-medium">
                  <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                  {session.isActive ? 'Class Live' : 'Class Paused'}
                </span>
              </div>
            </div>
          </div>

          {/* Session Timer & Attention Verification Status */}
          <div className="flex flex-wrap items-center gap-3">
            {/* Session Timer */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono tabular-nums text-slate-300">
              <Clock className="h-3.5 w-3.5 text-indigo-400" />
              <span>{elapsedTimer}</span>
            </div>

            {/* Verification Status */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-950/60 border border-indigo-800/60 text-xs text-indigo-300">
              <Headphones className="h-3.5 w-3.5 text-indigo-400" />
              <span className="hidden sm:inline">Verification:</span>
              <span className="font-semibold text-white">Audio Cues Active</span>
            </div>

            {/* Role Simulator Selector */}
            <div className="flex items-center gap-1 p-1 bg-slate-950 border border-slate-800 rounded-lg text-xs">
              <button
                onClick={() => setUserRole('teacher')}
                className={`px-2.5 py-1 rounded font-medium transition-colors ${
                  userRole === 'teacher' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
                }`}
              >
                Teacher View
              </button>
              <button
                onClick={() => setUserRole('student')}
                className={`px-2.5 py-1 rounded font-medium transition-colors ${
                  userRole === 'student' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
                }`}
              >
                Student View
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Classroom Body */}
      <div className="flex-1 mx-auto w-full max-w-7xl p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* ================= LEFT / CENTER: MAIN LECTURE STAGE ================= */}
        <div className="lg:col-span-8 flex flex-col space-y-4">
          {/* Lecture Stage & Virtual Board */}
          <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-6 shadow-xl flex-1 flex flex-col justify-between relative overflow-hidden">
            {/* Top Stage Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-indigo-400">
                  Lecture Presentation Stage
                </span>
                <h2 className="text-lg font-bold text-white mt-0.5">
                  Module 4: Minimum Spanning Trees & Graph Algorithms
                </h2>
              </div>

              {/* Student identity info (if viewing as student) */}
              {userRole === 'student' && (
                <div className="flex items-center gap-2 text-xs bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
                  <User className="h-3.5 w-3.5 text-slate-400" />
                  <span className="text-slate-400">Viewing as:</span>
                  <select
                    value={selectedStudentId}
                    onChange={(e) => setSelectedStudentId(e.target.value)}
                    className="bg-transparent text-indigo-300 font-semibold focus:outline-none"
                  >
                    {students.map((s) => (
                      <option key={s.id} value={s.id} className="bg-slate-900 text-white">
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            {/* Virtual Lecture Board Illustration (Interactive Whiteboard Content) */}
            <div className="my-6 p-5 rounded-xl bg-slate-950 border border-slate-800/90 font-mono text-xs text-slate-300 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-[11px] text-slate-400">
                <span className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-indigo-500" />
                  <span>Whiteboard: Greedy Edge Relaxation & Prim's Algorithm</span>
                </span>
                <span>Time Complexity: O(E log V)</span>
              </div>

              {/* SVG Graph Visualization */}
              <div className="h-44 w-full flex items-center justify-center">
                <svg className="w-full max-w-md h-full" viewBox="0 0 400 150">
                  {/* Edges */}
                  <line x1="60" y1="75" x2="160" y2="35" stroke="#475569" strokeWidth="2" />
                  <line x1="60" y1="75" x2="160" y2="115" stroke="#475569" strokeWidth="2" />
                  <line x1="160" y1="35" x2="260" y2="35" stroke="#6366f1" strokeWidth="3" />
                  <line x1="160" y1="115" x2="260" y2="115" stroke="#475569" strokeWidth="2" />
                  <line x1="160" y1="35" x2="260" y2="115" stroke="#6366f1" strokeWidth="2.5" strokeDasharray="4" />
                  <line x1="260" y1="35" x2="340" y2="75" stroke="#6366f1" strokeWidth="3" />
                  <line x1="260" y1="115" x2="340" y2="75" stroke="#475569" strokeWidth="2" />

                  {/* Edge weight labels */}
                  <text x="100" y="50" fill="#94a3b8" fontSize="10" textAnchor="middle">w=4</text>
                  <text x="100" y="105" fill="#94a3b8" fontSize="10" textAnchor="middle">w=8</text>
                  <text x="210" y="27" fill="#a5b4fc" fontSize="11" fontWeight="bold" textAnchor="middle">w=1 (MST)</text>
                  <text x="210" y="130" fill="#94a3b8" fontSize="10" textAnchor="middle">w=7</text>
                  <text x="310" y="50" fill="#a5b4fc" fontSize="11" fontWeight="bold" textAnchor="middle">w=2 (MST)</text>

                  {/* Nodes */}
                  <circle cx="60" cy="75" r="14" fill="#1e293b" stroke="#6366f1" strokeWidth="2" />
                  <text x="60" y="79" fill="#ffffff" fontSize="11" fontWeight="bold" textAnchor="middle">A</text>

                  <circle cx="160" cy="35" r="14" fill="#312e81" stroke="#818cf8" strokeWidth="2" />
                  <text x="160" y="39" fill="#ffffff" fontSize="11" fontWeight="bold" textAnchor="middle">B</text>

                  <circle cx="160" cy="115" r="14" fill="#1e293b" stroke="#64748b" strokeWidth="2" />
                  <text x="160" y="119" fill="#ffffff" fontSize="11" fontWeight="bold" textAnchor="middle">C</text>

                  <circle cx="260" cy="35" r="14" fill="#312e81" stroke="#818cf8" strokeWidth="2" />
                  <text x="260" y="39" fill="#ffffff" fontSize="11" fontWeight="bold" textAnchor="middle">D</text>

                  <circle cx="260" cy="115" r="14" fill="#1e293b" stroke="#64748b" strokeWidth="2" />
                  <text x="260" y="119" fill="#ffffff" fontSize="11" fontWeight="bold" textAnchor="middle">E</text>

                  <circle cx="340" cy="75" r="14" fill="#312e81" stroke="#818cf8" strokeWidth="2" />
                  <text x="340" y="79" fill="#ffffff" fontSize="11" fontWeight="bold" textAnchor="middle">F</text>
                </svg>
              </div>

              <div className="text-[11px] text-slate-400 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                <strong>Theorem 4.2 (Cut Property):</strong> For any cut C of the graph, if the weight of an edge e in the cut-set of C is strictly smaller than the weights of all other edges of C, then this edge belongs to all MSTs of the graph.
              </div>
            </div>

            {/* In-Classroom Attention Check Notification Bar */}
            {activeCheck && (
              <div className="rounded-xl border border-indigo-500/80 bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-950 p-4 shadow-xl animate-in zoom-in-95 duration-150">
                {!hasStudentResponded ? (
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-indigo-600 flex items-center justify-center text-white shrink-0 animate-bounce shadow-lg shadow-indigo-600/40">
                        <Headphones className="h-5 w-5" />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-white flex items-center gap-2">
                          <span>Attention Check — Respond Now</span>
                          <span className="text-xs font-mono text-amber-300">
                            ({checkTimeRemaining}s remaining)
                          </span>
                        </div>
                        <div className="text-xs text-indigo-200">
                          Harmonic cue sounded! Press SPACE or tap below to confirm presence.
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleStudentResponse()}
                        className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition-all active:scale-95 animate-pulse"
                      >
                        I'm Listening (SPACE)
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-3 text-emerald-400 text-xs font-medium">
                    <CheckCircle2 className="h-5 w-5" />
                    <div>
                      <strong className="text-white">Response recorded ✓</strong> Latency:{' '}
                      <span className="font-mono font-bold text-emerald-300">
                        {studentResponseTime !== null ? `${studentResponseTime.toFixed(1)}s` : '1.2s'}
                      </span>
                      . Continuing online lecture uninterrupted.
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Teacher In-Classroom Action Deck */}
            {userRole === 'teacher' && (
              <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => triggerAttentionCheck()}
                    disabled={activeCheck !== null}
                    className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all shadow-md active:scale-95 ${
                      activeCheck
                        ? 'bg-amber-600 text-white cursor-not-allowed opacity-80'
                        : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30'
                    }`}
                  >
                    <Volume2 className="h-4 w-4" />
                    <span>{activeCheck ? `Cue Active (${checkTimeRemaining}s)` : 'Send Attention Cue'}</span>
                  </button>

                  <button
                    onClick={() => testAudioCue()}
                    className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-indigo-300 text-xs font-medium border border-slate-700 transition-colors"
                  >
                    Audition Sound
                  </button>

                  <select
                    value={selectedCueType}
                    onChange={(e) => setSelectedCueType(e.target.value as CueType)}
                    className="bg-slate-950 border border-slate-800 text-xs rounded-lg px-2.5 py-2 text-slate-300 focus:outline-none"
                  >
                    <option value="gentle_chime">Gentle Chime</option>
                    <option value="sonar_ping">Sonar Ping</option>
                    <option value="warm_pulse">Warm Pulse</option>
                  </select>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setCurrentView('teacher')}
                    className="px-3 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-medium transition-colors"
                  >
                    Open Full Dashboard →
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* ================= RIGHT COLUMN: ROSTER & CLASS CHAT ================= */}
        <div className="lg:col-span-4 flex flex-col space-y-4">
          <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 shadow-xl flex-1 flex flex-col justify-between min-h-[500px]">
            {/* Tab Switcher */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-semibold">
                <button
                  onClick={() => setActiveTab('chat')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors ${
                    activeTab === 'chat'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <MessageSquare className="h-3.5 w-3.5" />
                  <span>Discussion ({classroomMessages.length})</span>
                </button>

                <button
                  onClick={() => setActiveTab('roster')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors ${
                    activeTab === 'roster'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Users className="h-3.5 w-3.5" />
                  <span>Enrolled ({students.length})</span>
                </button>
              </div>

              <div className="text-[11px] text-slate-400 flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-emerald-400" />
                <span>Connected</span>
              </div>
            </div>

            {/* TAB CONTENT: CHAT */}
            {activeTab === 'chat' && (
              <div className="flex-1 flex flex-col justify-between pt-3">
                {/* Messages stream */}
                <div className="flex-1 space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
                  {classroomMessages.map((msg) => {
                    const isTeacher = msg.role === 'teacher';
                    return (
                      <div
                        key={msg.id}
                        className={`p-2.5 rounded-xl text-xs space-y-1 ${
                          isTeacher
                            ? 'bg-indigo-950/60 border border-indigo-800/60 text-indigo-100'
                            : 'bg-slate-950 border border-slate-800 text-slate-200'
                        }`}
                      >
                        <div className="flex items-center justify-between text-[10px]">
                          <span
                            className={`font-bold ${
                              isTeacher ? 'text-indigo-400' : 'text-slate-400'
                            }`}
                          >
                            {msg.sender} {isTeacher && '(Instructor)'}
                          </span>
                          <span className="text-slate-500 font-mono">
                            {new Date(msg.timestamp).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>
                        <p className="leading-relaxed">{msg.text}</p>
                      </div>
                    );
                  })}
                </div>

                {/* Chat input form */}
                <form onSubmit={handleSendMessage} className="pt-3 border-t border-slate-800/80 flex gap-2">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder={
                      userRole === 'teacher'
                        ? 'Post announcement or reply as teacher...'
                        : `Ask a question as ${currentStudent.name.split(' ')[0]}...`
                    }
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                  <button
                    type="submit"
                    className="p-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors"
                  >
                    <Send className="h-4 w-4" />
                  </button>
                </form>
              </div>
            )}

            {/* TAB CONTENT: ROSTER */}
            {activeTab === 'roster' && (
              <div className="flex-1 pt-3 space-y-2 max-h-[460px] overflow-y-auto pr-1">
                {students.map((stu) => {
                  const isAttentive = stu.currentStatus === 'attentive';
                  const isActive = stu.currentStatus === 'active';

                  return (
                    <div
                      key={stu.id}
                      className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
                    >
                      <div>
                        <div className="font-semibold text-slate-200">{stu.name}</div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          Score: {stu.attentionScore}% · Latency: {stu.lastResponseTime !== null ? `${stu.lastResponseTime.toFixed(1)}s` : 'Did not respond'}
                        </div>
                      </div>

                      <div className="text-right">
                        <span
                          className={`text-[11px] font-semibold ${
                            isAttentive
                              ? 'text-emerald-400'
                              : isActive
                              ? 'text-indigo-300'
                              : 'text-amber-400'
                          }`}
                        >
                          {isAttentive ? 'Attentive' : isActive ? 'Active' : 'Needs Check'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Standalone Privacy Guarantee Footnote */}
      <footer className="border-t border-slate-800 bg-slate-950/80 px-4 py-3 text-xs text-slate-400">
        <div className="mx-auto max-w-7xl flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <EyeOff className="h-4 w-4 text-emerald-400 shrink-0" />
            <span>
              <strong>100% Non-Camera Standalone Classroom:</strong> Zero video streams, zero facial recognition, zero ambient mic recording.
            </span>
          </div>
          <span className="text-[11px] text-slate-500 font-mono">
            AttentionGuard Autonomous Class Engine
          </span>
        </div>
      </footer>
    </div>
  );
};
