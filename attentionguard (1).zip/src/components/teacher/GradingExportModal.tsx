import React, { useState, useMemo } from 'react';
import { Session, Student } from '../../types';
import {
  X,
  Download,
  Copy,
  Check,
  GraduationCap,
  FileSpreadsheet,
  Settings2,
  Table,
} from 'lucide-react';

interface GradingExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  session: Session;
  students: Student[];
}

type GradeScheme = 'letter' | 'points10' | 'points100' | 'pass_fail';

export const GradingExportModal: React.FC<GradingExportModalProps> = ({
  isOpen,
  onClose,
  session,
  students,
}) => {
  const [gradeScheme, setGradeScheme] = useState<GradeScheme>('letter');
  const [includeMetadataHeader, setIncludeMetadataHeader] = useState<boolean>(true);
  const [includeCheckBreakdown, setIncludeCheckBreakdown] = useState<boolean>(true);
  const [passThreshold, setPassThreshold] = useState<number>(70);
  const [copied, setCopied] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);

  // Maximum number of checks across all students to build dynamic check columns
  const maxChecks = useMemo(() => {
    return Math.max(...students.map(s => s.history.length), session.checksCompleted, 1);
  }, [students, session.checksCompleted]);

  // Helper to compute grade based on scheme
  const computeGrade = (score: number) => {
    if (gradeScheme === 'letter') {
      if (score >= 90) return 'A';
      if (score >= 80) return 'B';
      if (score >= 70) return 'C';
      if (score >= 60) return 'D';
      return 'F';
    } else if (gradeScheme === 'points10') {
      return (score / 10).toFixed(1);
    } else if (gradeScheme === 'points100') {
      return score.toString();
    } else {
      return score >= passThreshold ? 'PASS' : 'FAIL';
    }
  };

  // Helper to compute constructive academic remarks
  const computeRemarks = (s: Student) => {
    if (s.attentionScore >= 90) return 'Exemplary focus & rapid interaction';
    if (s.attentionScore >= 80) return 'Consistent active presence';
    if (s.attentionScore >= 70) return 'Satisfactory participation';
    if (s.missedCount >= 2) return 'Follow-up recommended: multiple cues missed';
    return 'Low responsiveness during session';
  };

  // Generate headers and data rows
  const { headers, rows, rawCsvString } = useMemo(() => {
    const baseHeaders = [
      'Student Name',
      'Student Email',
      'Total Checks',
      'Checks Responded',
      'Checks Missed',
      'Participation Rate (%)',
      'Avg Response Latency (s)',
      'Attention Score (0-100)',
      gradeScheme === 'letter'
        ? 'Letter Grade'
        : gradeScheme === 'points10'
        ? 'Participation Score (out of 10)'
        : gradeScheme === 'points100'
        ? 'Participation Score (out of 100)'
        : 'Result (Pass/Fail)',
      'Academic Status & Remarks',
    ];

    if (includeCheckBreakdown) {
      for (let i = 1; i <= maxChecks; i++) {
        baseHeaders.push(`Check #${i} (s)`);
      }
    }

    const dataRows = students.map((s) => {
      const participationRate =
        s.totalChecks > 0 ? Math.round((s.responseCount / s.totalChecks) * 100) : 0;
      const grade = computeGrade(s.attentionScore);
      const remarks = computeRemarks(s);
      const avgLatency =
        s.lastResponseTime !== null ? s.lastResponseTime.toFixed(2) : 'N/A';

      const row = [
        `"${s.name}"`,
        `"${s.email}"`,
        s.totalChecks.toString(),
        s.responseCount.toString(),
        s.missedCount.toString(),
        `${participationRate}%`,
        avgLatency,
        s.attentionScore.toString(),
        `"${grade}"`,
        `"${remarks}"`,
      ];

      if (includeCheckBreakdown) {
        for (let i = 0; i < maxChecks; i++) {
          const item = s.history[i];
          if (!item) {
            row.push('—');
          } else if (item.responseTime === null || item.status === 'missed') {
            row.push('"Missed"');
          } else {
            row.push(item.responseTime.toFixed(2));
          }
        }
      }

      return row;
    });

    let csvContent = '';

    if (includeMetadataHeader) {
      csvContent += `# AttentionGuard Academic Attendance & Attention Gradebook Export\n`;
      csvContent += `# Course: ${session.courseCode} - ${session.title}\n`;
      csvContent += `# Instructor: ${session.teacherName}\n`;
      csvContent += `# Export Generated: ${new Date().toLocaleString()}\n`;
      csvContent += `# Total Students Evaluated: ${students.length}\n`;
      csvContent += `# Grading Policy: ${
        gradeScheme === 'letter'
          ? 'Standard Letter Grade (A-F)'
          : gradeScheme === 'points10'
          ? 'Points scaled to 10.0'
          : gradeScheme === 'points100'
          ? 'Raw points out of 100'
          : `Pass/Fail (Threshold: ${passThreshold}%)`
      }\n`;
      csvContent += `# Privacy Guarantee: 100% Non-Camera Verification via Acoustic Micro-Interactions\n#\n`;
    }

    csvContent += headersToCsvLine(baseHeaders) + '\n';
    csvContent += dataRows.map((r) => r.join(',')).join('\n');

    return {
      headers: baseHeaders,
      rows: dataRows,
      rawCsvString: csvContent,
    };
  }, [
    students,
    gradeScheme,
    includeMetadataHeader,
    includeCheckBreakdown,
    maxChecks,
    passThreshold,
    session,
  ]);

  function headersToCsvLine(hList: string[]) {
    return hList.map((h) => (h.includes(',') ? `"${h}"` : h)).join(',');
  }

  // Handle Download CSV
  const handleDownload = () => {
    const blob = new Blob([rawCsvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const filename = `${session.courseCode}_Student_Attention_Grades_${new Date()
      .toISOString()
      .slice(0, 10)}.csv`;

    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  // Handle Copy to Clipboard
  const handleCopyClipboard = async () => {
    try {
      await navigator.clipboard.writeText(rawCsvString);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-4xl max-h-[90vh] flex flex-col rounded-2xl border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-2.5">
            <div className="h-9 w-9 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
              <GraduationCap className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                Export Session Attention Data for Grading
              </h2>
              <p className="text-xs text-slate-400">
                Generate an academic CSV gradebook file compatible with Canvas, Blackboard, Moodle, and Excel
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Content Scrollable Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Grading Configuration Controls */}
          <div className="rounded-xl border border-slate-800 bg-slate-950/80 p-5 space-y-4">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-indigo-400">
              <Settings2 className="h-4 w-4" />
              <span>Grading Scheme & Output Preferences</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Grading Scheme Selector */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Grading Scheme:
                </label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    onClick={() => setGradeScheme('letter')}
                    className={`p-2.5 rounded-lg border text-left transition-colors ${
                      gradeScheme === 'letter'
                        ? 'bg-indigo-600/20 border-indigo-500 text-white font-semibold'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="text-indigo-400 font-bold mb-0.5">Letter Grades</div>
                    <div className="text-[11px] text-slate-400">A, B, C, D, F</div>
                  </button>

                  <button
                    onClick={() => setGradeScheme('points10')}
                    className={`p-2.5 rounded-lg border text-left transition-colors ${
                      gradeScheme === 'points10'
                        ? 'bg-indigo-600/20 border-indigo-500 text-white font-semibold'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="text-indigo-400 font-bold mb-0.5">Points (10 max)</div>
                    <div className="text-[11px] text-slate-400">e.g. 9.2 / 10</div>
                  </button>

                  <button
                    onClick={() => setGradeScheme('points100')}
                    className={`p-2.5 rounded-lg border text-left transition-colors ${
                      gradeScheme === 'points100'
                        ? 'bg-indigo-600/20 border-indigo-500 text-white font-semibold'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="text-indigo-400 font-bold mb-0.5">Points (100 max)</div>
                    <div className="text-[11px] text-slate-400">Raw attention score %</div>
                  </button>

                  <button
                    onClick={() => setGradeScheme('pass_fail')}
                    className={`p-2.5 rounded-lg border text-left transition-colors ${
                      gradeScheme === 'pass_fail'
                        ? 'bg-indigo-600/20 border-indigo-500 text-white font-semibold'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="text-indigo-400 font-bold mb-0.5">Pass / Fail</div>
                    <div className="text-[11px] text-slate-400">Custom cutoff</div>
                  </button>
                </div>

                {gradeScheme === 'pass_fail' && (
                  <div className="mt-3 flex items-center gap-3 text-xs bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                    <span className="text-slate-400">Pass Cutoff:</span>
                    <input
                      type="range"
                      min="50"
                      max="90"
                      value={passThreshold}
                      onChange={(e) => setPassThreshold(parseInt(e.target.value))}
                      className="accent-indigo-500 flex-1"
                    />
                    <span className="font-mono text-indigo-300 font-bold">{passThreshold}%</span>
                  </div>
                )}
              </div>

              {/* Toggles */}
              <div className="space-y-3 text-xs">
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  CSV Formatting Options:
                </label>

                <label className="flex items-center gap-2.5 p-2.5 rounded-lg bg-slate-900 border border-slate-800 cursor-pointer hover:border-slate-700 transition-colors">
                  <input
                    type="checkbox"
                    checked={includeMetadataHeader}
                    onChange={(e) => setIncludeMetadataHeader(e.target.checked)}
                    className="accent-indigo-600 h-4 w-4 rounded"
                  />
                  <div>
                    <div className="font-semibold text-slate-200">Include Course Metadata Header</div>
                    <div className="text-[11px] text-slate-400">
                      Adds Course Code, Instructor, Date & Timestamp at the top of the file
                    </div>
                  </div>
                </label>

                <label className="flex items-center gap-2.5 p-2.5 rounded-lg bg-slate-900 border border-slate-800 cursor-pointer hover:border-slate-700 transition-colors">
                  <input
                    type="checkbox"
                    checked={includeCheckBreakdown}
                    onChange={(e) => setIncludeCheckBreakdown(e.target.checked)}
                    className="accent-indigo-600 h-4 w-4 rounded"
                  />
                  <div>
                    <div className="font-semibold text-slate-200">Include Per-Check Latencies</div>
                    <div className="text-[11px] text-slate-400">
                      Adds columns for Check #1, Check #2, Check #3 with individual response times
                    </div>
                  </div>
                </label>
              </div>
            </div>
          </div>

          {/* Live Data Preview Table */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 font-semibold text-slate-300">
                <Table className="h-4 w-4 text-indigo-400" />
                <span>Live CSV Gradebook Preview ({students.length} students)</span>
              </div>
              <span className="text-[11px] text-slate-400 font-mono">
                {headers.length} columns configured
              </span>
            </div>

            <div className="rounded-xl border border-slate-800 bg-slate-950 overflow-hidden">
              <div className="max-h-56 overflow-auto">
                <table className="w-full text-left text-[11px]">
                  <thead className="bg-slate-900 text-slate-400 uppercase font-semibold sticky top-0 border-b border-slate-800 whitespace-nowrap">
                    <tr>
                      {headers.map((h, i) => (
                        <th key={i} className="py-2.5 px-3">
                          {h.replace(/"/g, '')}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80 font-normal whitespace-nowrap">
                    {rows.map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-900/60 transition-colors">
                        {row.map((cell, cIdx) => (
                          <td key={cIdx} className="py-2 px-3 text-slate-300">
                            {cell.replace(/"/g, '')}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer Actions */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-slate-400 flex items-center gap-2">
            <FileSpreadsheet className="h-4 w-4 text-emerald-400 shrink-0" />
            <span>Format: Standard CSV (RFC 4180) ready for gradebook import</span>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={handleCopyClipboard}
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors border border-slate-700"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copied ? 'Copied CSV ✓' : 'Copy CSV Text'}</span>
            </button>

            <button
              onClick={handleDownload}
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition-all active:scale-95"
            >
              {downloadSuccess ? (
                <>
                  <Check className="h-4 w-4 text-white" />
                  <span>Downloaded!</span>
                </>
              ) : (
                <>
                  <Download className="h-4 w-4" />
                  <span>Download Grading CSV</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
