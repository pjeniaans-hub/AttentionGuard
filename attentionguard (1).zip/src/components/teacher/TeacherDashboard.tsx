import React, { useState, useMemo, useEffect } from 'react';
import { useSession } from '../../context/SessionContext';
import {
  Users,
  CheckCircle,
  AlertTriangle,
  Activity,
  Play,
  Square,
  Volume2,
  RefreshCw,
  Search,
  Download,
  Clock,
  Sparkles,
  Info,
  ChevronDown,
  GraduationCap,
  BookOpen,
  ArrowRight,
  Zap,
} from 'lucide-react';
import { CueType, StudentStatus, Student } from '../../types';
import { GradingExportModal } from './GradingExportModal';
import { formatCountdown } from '../../utils/scheduling';

export const TeacherDashboard: React.FC = () => {
  const {
    session,
    students,
    pastChecks,
    triggerAttentionCheck,
    triggerAllStaggeredChecks,
    startSession,
    endSession,
    resetDemoData,
    selectedCueType,
    setSelectedCueType,
    testAudioCue,
    scheduleMode,
    setScheduleMode,
    setCurrentView,
  } = useSession();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | StudentStatus>('all');
  const [selectedStudentDetail, setSelectedStudentDetail] = useState<string | null>(null);
  const [isGradingExportOpen, setIsGradingExportOpen] = useState(false);

  // Live second ticker for accurate per-student countdown rendering
  const [, setTick] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => setTick((t) => t + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  // Helper to compute average latency
  const calcAvgLatency = (s: Student) => {
    const answered = s.history.filter((h) => h.responseTime !== null && h.status !== 'missed');
    if (answered.length === 0) return '—';
    const sum = answered.reduce((acc, h) => acc + (h.responseTime || 0), 0);
    return `${(sum / answered.length).toFixed(1)}s`;
  };

  // Statistics calculation
  const totalStudents = students.length;
  const attentiveCount = students.filter(s => s.currentStatus === 'attentive').length;
  const activeCount = students.filter(s => s.currentStatus === 'active').length;
  const needsAttentionCount = students.filter(s => s.currentStatus === 'needs_attention').length;
  const avgAttentionScore = totalStudents > 0
    ? Math.round(students.reduce((acc, curr) => acc + curr.attentionScore, 0) / totalStudents)
    : 0;

  // Filter students
  const filteredStudents = useMemo(() => {
    return students.filter(s => {
      const matchesSearch = s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.email.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === 'all' || s.currentStatus === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [students, searchQuery, statusFilter]);

  // Response time distribution metrics
  const distribution = useMemo(() => {
    let under2 = 0;
    let twoToFive = 0;
    let over5 = 0;
    let missed = 0;

    students.forEach(s => {
      if (s.lastResponseTime === null || s.lastResponseStatus === 'missed') {
        missed++;
      } else if (s.lastResponseTime <= 2.0) {
        under2++;
      } else if (s.lastResponseTime <= 5.0) {
        twoToFive++;
      } else {
        over5++;
      }
    });

    return { under2, twoToFive, over5, missed };
  }, [students]);

  // Export CSV summary
  const handleExportCSV = () => {
    const headers = ['Student Name', 'Email', 'Response Status', 'Last Response Time (s)', 'Attention Score (%)', 'Current Status'];
    const rows = students.map(s => [
      `"${s.name}"`,
      `"${s.email}"`,
      s.lastResponseStatus === 'missed' ? 'Did not respond' : s.lastResponseStatus,
      s.lastResponseTime !== null ? s.lastResponseTime : 'N/A',
      s.attentionScore,
      s.currentStatus === 'attentive' ? 'Attentive' : s.currentStatus === 'active' ? 'Active' : 'Needs attention check',
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `AttentionGuard_Report_${session.courseCode}_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-slate-950 py-8 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl space-y-8">
        {/* Top Header / Breadcrumb Bar */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-slate-800 pb-6">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
              <span>{session.courseCode}</span>
              <span>/</span>
              <span>{session.title}</span>
              <span>/</span>
              <span className="text-indigo-400 font-medium">{session.teacherName}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Teacher Oversight Console
            </h1>
          </div>

          {/* Session Actions */}
          <div className="flex flex-wrap items-center gap-3">
            {/* Visible Demo Mode Indicator and Mode Switcher */}
            <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 p-1 rounded-xl text-xs">
              {scheduleMode === 'demo' ? (
                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30">
                  <span className="h-2 w-2 rounded-full bg-amber-400 animate-pulse" />
                  <span>Demo Mode (10–20s)</span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 font-semibold border border-emerald-500/30">
                  <span className="h-2 w-2 rounded-full bg-emerald-400" />
                  <span>Real Class Mode (~2m)</span>
                </div>
              )}

              <button
                onClick={() => setScheduleMode(scheduleMode === 'demo' ? 'real' : 'demo')}
                className="px-2.5 py-1 rounded-lg text-slate-400 hover:text-white transition-colors"
                title="Switch between Hackathon Demo speed (10-20s) and Real Class speed (90-150s)"
              >
                Switch to {scheduleMode === 'demo' ? 'Real (~2m)' : 'Demo (10–20s)'}
              </button>
            </div>

            {session.isActive ? (
              <>
                <button
                  onClick={() => triggerAllStaggeredChecks()}
                  className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition-all active:scale-95"
                  title="Schedules all students with independent staggered random check delays"
                >
                  <Volume2 className="h-4 w-4" />
                  <span>Stagger All Checks</span>
                </button>

                <button
                  onClick={endSession}
                  className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 text-xs font-medium transition-colors"
                >
                  <Square className="h-3.5 w-3.5 fill-rose-300" />
                  <span>End Session</span>
                </button>
              </>
            ) : (
              <button
                onClick={startSession}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-sm transition-all"
              >
                <Play className="h-3.5 w-3.5 fill-white" />
                <span>Start Session</span>
              </button>
            )}

            <button
              onClick={() => setIsGradingExportOpen(true)}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-indigo-950/80 border border-indigo-700/60 text-indigo-200 hover:text-white hover:bg-indigo-900/80 text-xs font-semibold shadow-sm transition-all active:scale-95"
              title="Export student attention data as CSV for grading"
            >
              <GraduationCap className="h-4 w-4 text-indigo-400" />
              <span>Export for Grading (CSV)</span>
            </button>

            <button
              onClick={resetDemoData}
              className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-colors"
              title="Reset sample classroom data"
            >
              <RefreshCw className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* AttentionGuard Built-in Online Classroom Hub */}
        <div className="rounded-2xl border border-indigo-900/50 bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 p-5 shadow-lg space-y-3">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="flex items-start sm:items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center shrink-0">
                <BookOpen className="h-5 w-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-white">AttentionGuard Online Classroom</span>
                  <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-xs font-semibold text-emerald-400">Class Active</span>
                </div>
                <div className="text-xs text-slate-400 mt-0.5">
                  {session.courseCode} · {session.title} — {session.teacherName}
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <button
                onClick={() => setCurrentView('classroom')}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-xs font-bold shadow-md shadow-indigo-600/20 transition-all active:scale-95"
              >
                <BookOpen className="h-4 w-4" />
                <span>Enter Live Classroom</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>

              <button
                onClick={() => triggerAllStaggeredChecks()}
                disabled={!session.isActive}
                className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 text-xs font-medium transition-colors"
                title="Schedules independent random cues for all enrolled students"
              >
                <Volume2 className="h-3.5 w-3.5 text-indigo-400" />
                <span>Stagger All Student Cues</span>
              </button>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 flex items-center gap-2">
            <span className="text-indigo-400 font-semibold">Privacy Policy:</span>
            <span>AttentionGuard operates as a 100% non-camera standalone classroom. No webcam, face detection, or microphone recording is used.</span>
          </div>
        </div>

        {/* Top 4 Statistics Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Active Students */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-medium text-slate-400">Active Students</span>
              <div className="h-8 w-8 rounded-lg bg-slate-800 flex items-center justify-center text-slate-300">
                <Users className="h-4 w-4" />
              </div>
            </div>
            <div className="text-2xl font-bold font-mono tabular-nums text-white">
              {totalStudents}
            </div>
            <div className="mt-1 text-xs text-slate-400 flex items-center gap-1">
              <span className="h-2 w-2 rounded-full bg-emerald-400" />
              <span>100% connected to session</span>
            </div>
          </div>

          {/* Students Attentive */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-medium text-slate-400">Students Attentive</span>
              <div className="h-8 w-8 rounded-lg bg-emerald-950/70 border border-emerald-800/50 flex items-center justify-center text-emerald-400">
                <CheckCircle className="h-4 w-4" />
              </div>
            </div>
            <div className="text-2xl font-bold font-mono tabular-nums text-emerald-400">
              {attentiveCount}
            </div>
            <div className="mt-1 text-xs text-slate-400">
              <span className="text-emerald-400 font-medium">{Math.round((attentiveCount / totalStudents) * 100)}%</span>
              <span className="ml-1">rapid response rate (≥85%)</span>
            </div>
          </div>

          {/* Students Needing Attention */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-medium text-slate-400">Needs Attention Check</span>
              <div className="h-8 w-8 rounded-lg bg-amber-950/70 border border-amber-800/50 flex items-center justify-center text-amber-400">
                <AlertTriangle className="h-4 w-4" />
              </div>
            </div>
            <div className="text-2xl font-bold font-mono tabular-nums text-amber-400">
              {needsAttentionCount}
            </div>
            <div className="mt-1 text-xs text-slate-400">
              <span>Delayed or missed recent cues</span>
            </div>
          </div>

          {/* Average Attention Score */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-medium text-slate-400">Average Attention Score</span>
              <div className="h-8 w-8 rounded-lg bg-indigo-950/70 border border-indigo-800/50 flex items-center justify-center text-indigo-400">
                <Activity className="h-4 w-4" />
              </div>
            </div>
            <div className="text-2xl font-bold font-mono tabular-nums text-indigo-300">
              {avgAttentionScore}%
            </div>
            <div className="mt-1 text-xs text-slate-400">
              <span>Weighted interaction average</span>
            </div>
          </div>
        </div>

        {/* Live Audio & Cue Controls Strip */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-lg bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
              <Volume2 className="h-4 w-4" />
            </div>
            <div>
              <div className="text-xs font-semibold text-white">Audio Cue Configuration</div>
              <div className="text-[11px] text-slate-400">Tone delivered to student endpoints at randomized intervals</div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="text-slate-400">Chime:</span>
              <select
                value={selectedCueType}
                onChange={(e) => {
                  const val = e.target.value as CueType;
                  setSelectedCueType(val);
                  testAudioCue(val);
                }}
                className="bg-slate-950 border border-slate-800 rounded-md px-2.5 py-1 text-slate-200 focus:outline-none focus:border-indigo-500"
              >
                <option value="gentle_chime">Gentle Chime (Dual Sine)</option>
                <option value="sonar_ping">Sonar Ping (Harmonic Triangle)</option>
                <option value="warm_pulse">Warm Pulse (Octave Sine)</option>
              </select>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => testAudioCue()}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-indigo-300 transition-colors border border-slate-700 font-medium"
              >
                Audition Tone
              </button>
            </div>

            <div className="h-4 w-[1px] bg-slate-800 hidden sm:block" />

            {/* Independent Schedule Mode selector */}
            <div className="flex items-center gap-2">
              <span className="text-slate-400">Random Interval Mode:</span>
              <button
                onClick={() => setScheduleMode(scheduleMode === 'demo' ? 'real' : 'demo')}
                className={`px-2.5 py-1 rounded font-medium border text-xs transition-colors ${
                  scheduleMode === 'demo'
                    ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                    : 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300'
                }`}
                title="Toggles between Hackathon Demo Mode (10–20s) and Real Class Mode (90–150s ~ 2min)"
              >
                {scheduleMode === 'demo' ? '⚡ Demo Mode (10–20s / student)' : '⏱ Real Mode (90–150s / student)'}
              </button>
            </div>
          </div>
        </div>

        {/* Analytics Charts & Graphs Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Live Attention Chart (Past checks line chart) */}
          <div className="lg:col-span-2 rounded-xl border border-slate-800 bg-slate-900/60 p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-white">Live Attention Timeline</h3>
                <p className="text-xs text-slate-400">Class engagement across recent attention cues</p>
              </div>
              <div className="text-xs text-slate-400 font-mono tabular-nums">
                {pastChecks.length} checks logged
              </div>
            </div>

            {/* SVG Waveform Chart */}
            <div className="h-44 w-full relative flex items-end pt-4 pb-6">
              <svg className="w-full h-full overflow-visible" viewBox="0 0 500 120" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#6366f1" stopOpacity="0.4" />
                    <stop offset="100%" stopColor="#6366f1" stopOpacity="0.0" />
                  </linearGradient>
                </defs>
                {/* Horizontal reference grid lines */}
                <line x1="0" y1="10" x2="500" y2="10" stroke="#1e293b" strokeDasharray="3 3" />
                <line x1="0" y1="50" x2="500" y2="50" stroke="#1e293b" strokeDasharray="3 3" />
                <line x1="0" y1="90" x2="500" y2="90" stroke="#1e293b" strokeDasharray="3 3" />

                {/* Simulated line points */}
                <path
                  d="M 20 25 Q 80 40, 140 28 T 260 45 T 380 32 T 480 20"
                  fill="none"
                  stroke="#6366f1"
                  strokeWidth="2.5"
                />
                <path
                  d="M 20 25 Q 80 40, 140 28 T 260 45 T 380 32 T 480 20 L 480 120 L 20 120 Z"
                  fill="url(#areaGradient)"
                />

                {/* Data Points */}
                {[
                  { cx: 20, cy: 25, label: '92%' },
                  { cx: 140, cy: 28, label: '90%' },
                  { cx: 260, cy: 45, label: '84%' },
                  { cx: 380, cy: 32, label: '89%' },
                  { cx: 480, cy: 20, label: '94%' },
                ].map((pt, i) => (
                  <g key={i}>
                    <circle cx={pt.cx} cy={pt.cy} r="4" fill="#a5b4fc" stroke="#0f172a" strokeWidth="2" />
                    <text
                      x={pt.cx}
                      y={pt.cy - 8}
                      textAnchor="middle"
                      fill="#94a3b8"
                      fontSize="9"
                      fontFamily="monospace"
                    >
                      {pt.label}
                    </text>
                  </g>
                ))}
              </svg>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800/80 pt-2 font-mono">
              <span>Session Start (00:00)</span>
              <span>Mid-Lecture (18:00)</span>
              <span>Latest (Current)</span>
            </div>
          </div>

          {/* Response Time Distribution Graph */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-semibold text-white mb-1">Response-Time Graph</h3>
              <p className="text-xs text-slate-400 mb-4">Latest check latency breakdown</p>

              <div className="space-y-3">
                {/* <2s */}
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-300">Strong (≤ 2.0s)</span>
                    <span className="font-mono text-emerald-400 font-semibold">{distribution.under2} students</span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                      style={{ width: `${(distribution.under2 / totalStudents) * 100}%` }}
                    />
                  </div>
                </div>

                {/* 2-5s */}
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-300">Normal (2.1s - 5.0s)</span>
                    <span className="font-mono text-indigo-400 font-semibold">{distribution.twoToFive} students</span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-indigo-500 rounded-full transition-all duration-500"
                      style={{ width: `${(distribution.twoToFive / totalStudents) * 100}%` }}
                    />
                  </div>
                </div>

                {/* >5s */}
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-300">Delayed (&gt; 5.0s)</span>
                    <span className="font-mono text-amber-400 font-semibold">{distribution.over5} students</span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-amber-500 rounded-full transition-all duration-500"
                      style={{ width: `${(distribution.over5 / totalStudents) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Missed */}
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-300">No Response / Missed</span>
                    <span className="font-mono text-rose-400 font-semibold">{distribution.missed} students</span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-rose-500 rounded-full transition-all duration-500"
                      style={{ width: `${(distribution.missed / totalStudents) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] text-slate-400 flex items-center gap-1.5">
              <Info className="h-3.5 w-3.5 text-slate-400 shrink-0" />
              <span>Latency reflects micro-interaction time, preserving complete visual privacy.</span>
            </div>
          </div>
        </div>

        {/* Student Table Section */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 overflow-hidden">
          {/* Table Header Controls */}
          <div className="p-4 sm:p-5 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-base font-bold text-white">Student Roster & Attention Ledger</h2>
              <p className="text-xs text-slate-400">Real-time attendance indicators and response status</p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              {/* Search Bar */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search student..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 w-44"
                />
              </div>

              {/* Status Segmented Tabs */}
              <div className="flex items-center gap-1 p-1 bg-slate-950 border border-slate-800 rounded-lg text-xs font-medium">
                {(['all', 'attentive', 'active', 'needs_attention'] as const).map(tab => (
                  <button
                    key={tab}
                    onClick={() => setStatusFilter(tab)}
                    className={`px-2.5 py-1 rounded-md transition-colors capitalize ${
                      statusFilter === tab
                        ? 'bg-slate-800 text-white font-semibold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {tab === 'needs_attention' ? 'Needs Attention' : tab}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Table Body */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/80 text-slate-400 uppercase text-[11px] font-semibold border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4 sm:px-6">Student Name</th>
                  <th className="py-3 px-4">Next Attention Check</th>
                  <th className="py-3 px-4">Last Latency</th>
                  <th className="py-3 px-4">Checks (Resp / Miss)</th>
                  <th className="py-3 px-4">Avg Latency</th>
                  <th className="py-3 px-4">Attention Indicator</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 font-normal">
                {filteredStudents.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-400">
                      No students match the selected filter.
                    </td>
                  </tr>
                ) : (
                  filteredStudents.map((s) => {
                    const isAttentive = s.currentStatus === 'attentive';
                    const isActive = s.currentStatus === 'active';
                    const isNeedsAttention = s.currentStatus === 'needs_attention';

                    return (
                      <tr
                        key={s.id}
                        className="hover:bg-slate-800/40 transition-colors cursor-pointer group"
                        onClick={() => setSelectedStudentDetail(selectedStudentDetail === s.id ? null : s.id)}
                      >
                        {/* Student Name */}
                        <td className="py-3.5 px-4 sm:px-6">
                          <div className="font-semibold text-slate-200 group-hover:text-indigo-300 transition-colors">
                            {s.name}
                          </div>
                          <div className="text-[11px] text-slate-400">{s.email}</div>
                        </td>

                        {/* Next Attention Check (Independent Countdown) */}
                        <td className="py-3.5 px-4">
                          {s.activeCheck ? (
                            <span className="inline-flex items-center gap-1 text-amber-300 font-bold bg-amber-500/15 px-2 py-0.5 rounded border border-amber-500/40 animate-pulse text-[11px]">
                              <Zap className="h-3 w-3" /> Prompt Active
                            </span>
                          ) : (
                            <span className="font-mono text-indigo-300 font-medium text-[11px] flex items-center gap-1">
                              <Clock className="h-3 w-3 text-slate-500" />
                              <span>{formatCountdown(s.nextCheckTimestamp)}</span>
                            </span>
                          )}
                        </td>

                        {/* Last Response Latency */}
                        <td className="py-3.5 px-4 font-mono tabular-nums text-slate-300">
                          {s.lastResponseTime !== null ? `${s.lastResponseTime.toFixed(1)}s` : 'Did not respond'}
                        </td>

                        {/* Checks (Resp / Miss) */}
                        <td className="py-3.5 px-4 font-mono tabular-nums text-slate-300">
                          <span>{s.totalChecks} checks</span>
                          <span className="text-[10px] text-slate-500 block">
                            ({s.responseCount} resp, {s.missedCount} miss)
                          </span>
                        </td>

                        {/* Avg Latency */}
                        <td className="py-3.5 px-4 font-mono tabular-nums text-slate-300">
                          {calcAvgLatency(s)}
                        </td>

                        {/* Interaction / Attention Indicator */}
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-2">
                            <span className="font-mono tabular-nums font-semibold text-slate-200">
                              {s.attentionScore}%
                            </span>
                            <div className="h-1.5 w-14 rounded-full bg-slate-800 overflow-hidden hidden sm:block">
                              <div
                                className={`h-full rounded-full ${
                                  s.attentionScore >= 85
                                    ? 'bg-emerald-500'
                                    : s.attentionScore >= 70
                                    ? 'bg-indigo-500'
                                    : 'bg-amber-500'
                                }`}
                                style={{ width: `${s.attentionScore}%` }}
                              />
                            </div>
                            <span
                              className={`text-[10px] font-semibold px-1.5 py-0.2 rounded ${
                                isAttentive
                                  ? 'text-emerald-400 bg-emerald-950/60'
                                  : isActive
                                  ? 'text-indigo-300 bg-indigo-950/60'
                                  : 'text-amber-400 bg-amber-950/60'
                              }`}
                            >
                              {isAttentive ? 'Attentive' : isActive ? 'Active' : 'Needs Check'}
                            </span>
                          </div>
                        </td>

                        {/* Action: Trigger Cue & History */}
                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                triggerAttentionCheck(s.id);
                              }}
                              disabled={s.activeCheck !== null}
                              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-indigo-300 hover:text-white transition-colors text-[11px] font-medium border border-slate-700 disabled:opacity-50"
                              title={`Send instant attention cue to ${s.name} only`}
                            >
                              Send Cue
                            </button>

                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedStudentDetail(selectedStudentDetail === s.id ? null : s.id);
                              }}
                              className="text-[11px] text-slate-400 hover:text-white transition-colors"
                            >
                              {selectedStudentDetail === s.id ? 'Close' : 'History'}
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Student Detail Drawer / Modal Accordion */}
          {selectedStudentDetail && (() => {
            const stu = students.find(s => s.id === selectedStudentDetail);
            if (!stu) return null;
            return (
              <div className="p-5 bg-slate-950/95 border-t border-slate-800 space-y-3 animate-in fade-in duration-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-sm">{stu.name}</span>
                    <span className="text-xs text-slate-400 font-mono">({stu.email})</span>
                  </div>
                  <button
                    onClick={() => setSelectedStudentDetail(null)}
                    className="text-xs text-slate-400 hover:text-white"
                  >
                    Close Log ×
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-2.5 rounded bg-slate-900 border border-slate-800">
                    <div className="text-slate-400 text-[10px]">Total Checks</div>
                    <div className="font-mono text-sm font-bold text-white">{stu.totalChecks}</div>
                  </div>
                  <div className="p-2.5 rounded bg-slate-900 border border-slate-800">
                    <div className="text-slate-400 text-[10px]">Responses Recorded</div>
                    <div className="font-mono text-sm font-bold text-emerald-400">{stu.responseCount}</div>
                  </div>
                  <div className="p-2.5 rounded bg-slate-900 border border-slate-800">
                    <div className="text-slate-400 text-[10px]">Response Missed</div>
                    <div className="font-mono text-sm font-bold text-rose-400">{stu.missedCount}</div>
                  </div>
                  <div className="p-2.5 rounded bg-slate-900 border border-slate-800">
                    <div className="text-slate-400 text-[10px]">Participation Rate</div>
                    <div className="font-mono text-sm font-bold text-indigo-300">
                      {stu.totalChecks > 0 ? Math.round((stu.responseCount / stu.totalChecks) * 100) : 100}%
                    </div>
                  </div>
                </div>

                <div className="pt-2">
                  <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                    Interaction Log
                  </div>
                  <div className="space-y-1 max-h-36 overflow-y-auto pr-1">
                    {stu.history.map((h, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between text-xs py-1 px-2.5 rounded bg-slate-900/60 border border-slate-800/80"
                      >
                        <span className="text-slate-400 font-mono text-[11px]">
                          Check #{idx + 1}
                        </span>
                        <span className="capitalize text-slate-300">
                          {h.status === 'missed' ? 'Response Missed' : `${h.status} response`}
                        </span>
                        <span className="font-mono text-slate-200">
                          {h.responseTime !== null ? `${h.responseTime.toFixed(1)}s` : '—'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })()}
        </div>

        {/* Transparent Methodology & Privacy Footnote */}
        <div className="rounded-xl border border-slate-800/90 bg-slate-900/40 p-4 text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-indigo-400 shrink-0" />
            <span>
              <strong>Attention scoring policy:</strong> Attention scores indicate audio cue response participation. They do not constitute continuous cognitive or visual surveillance.
            </span>
          </div>
          <button
            onClick={() => setCurrentView('privacy')}
            className="text-indigo-400 hover:text-indigo-300 font-medium whitespace-nowrap"
          >
            Read Privacy Architecture →
          </button>
        </div>

        {/* Modal for Grading CSV Export */}
        <GradingExportModal
          isOpen={isGradingExportOpen}
          onClose={() => setIsGradingExportOpen(false)}
          session={session}
          students={students}
        />
      </div>
    </div>
  );
};
