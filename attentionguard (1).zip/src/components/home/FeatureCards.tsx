import React from 'react';
import { Headphones, Shield, Brain, Clock, BarChart3, Zap } from 'lucide-react';

export const FeatureCards: React.FC = () => {
  const features = [
    {
      icon: Headphones,
      title: 'Audio-Based Verification',
      category: 'Acoustic Interaction',
      description:
        'Uses pleasant harmonic synthesized audio cues delivered directly via web browser. Students respond with a single tap, confirming active presence without video.',
      benefit: 'Zero intrusive video or ambient mic recording',
      color: 'indigo',
    },
    {
      icon: Shield,
      title: 'Camera-Free & Privacy-Friendly',
      category: 'Ethical Design',
      description:
        'No webcams, no facial recognition, no gaze tracking, and no emotion AI. Completely protects home environments, roommates, and personal boundaries.',
      benefit: '100% compliant with student privacy laws',
      color: 'emerald',
    },
    {
      icon: Brain,
      title: 'Smart Attention Scoring',
      category: 'Transparent Analytics',
      description:
        'Calculates attention through objective response latency algorithms. Replaces invasive guesswork with honest, neutral interaction metrics.',
      benefit: 'Transparent formulas with zero black-box bias',
      color: 'violet',
    },
    {
      icon: Clock,
      title: 'Random Interaction Timing',
      category: 'Predictability Prevention',
      description:
        'Cues fire at non-periodic, randomized intervals between 3 and 15 minutes. Prevents passive tab muting while keeping distraction to a minimum.',
      benefit: 'Students remain comfortably dialed in',
      color: 'amber',
    },
    {
      icon: BarChart3,
      title: 'Real-Time Analytics',
      category: 'Educator Telemetry',
      description:
        'Instructors view instant class-wide engagement curves, response-time histograms, and attendance histories to gauge comprehension pace.',
      benefit: 'Identify lecture fatigue before comprehension drops',
      color: 'cyan',
    },
    {
      icon: Zap,
      title: 'Instant Response Tracking',
      category: 'High Performance',
      description:
        'Sub-second latency capture records keyboard presses (Spacebar / Enter) or button taps with millisecond precision for indisputable records.',
      benefit: 'Immediate teacher feedback loop',
      color: 'rose',
    },
  ];

  return (
    <section className="py-16 md:py-24 border-t border-slate-800/80 bg-slate-950">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto text-center space-y-3 mb-14">
          <div className="text-xs font-semibold uppercase tracking-wider text-indigo-400">
            Engineered For Higher Education & Professional Meetings
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
            Six Pillars of Non-Camera Presence
          </h2>
          <p className="text-sm sm:text-base text-slate-400 leading-relaxed">
            Eliminating surveillance fatigue while restoring instructor confidence through lightweight, audio-driven interaction.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((f, i) => {
            const IconComponent = f.icon;
            return (
              <div
                key={i}
                className="group relative rounded-xl border border-slate-800/90 bg-slate-900/60 p-6 transition-all duration-200 hover:border-slate-700 hover:bg-slate-900/90 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="h-10 w-10 rounded-lg bg-slate-800 flex items-center justify-center text-indigo-400 group-hover:text-indigo-300 transition-colors">
                      <IconComponent className="h-5 w-5" />
                    </div>
                    {/* Unboxed metadata according to constitution */}
                    <div className="text-xs text-slate-400 font-medium">
                      <span>{f.category}</span>
                    </div>
                  </div>

                  <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-indigo-200 transition-colors">
                    {f.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-slate-400 leading-relaxed mb-4">
                    {f.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-800/80 text-xs text-emerald-400 flex items-center gap-1.5 font-medium">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                  <span>{f.benefit}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
