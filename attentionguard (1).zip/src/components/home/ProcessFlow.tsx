import React, { useState } from 'react';
import { useSession } from '../../context/SessionContext';
import { PlayCircle, Volume2, Keyboard, LineChart, CheckCircle2, ArrowRight } from 'lucide-react';
import { CueType } from '../../types';

export const ProcessFlow: React.FC = () => {
  const { testAudioCue, triggerAttentionCheck, setCurrentView } = useSession();
  const [activeStep, setActiveStep] = useState<number>(1);
  const [sampleCue, setSampleCue] = useState<CueType>('gentle_chime');
  const [testPressed, setTestPressed] = useState<boolean>(false);
  const [testResponseTime, setTestResponseTime] = useState<number | null>(null);

  const steps = [
    {
      step: 1,
      title: 'Teacher starts an online session',
      subtitle: 'Session Initialization',
      desc: 'The instructor launches the built-in AttentionGuard online classroom. No cameras, software installations, or invasive monitoring permissions are required for students.',
      icon: PlayCircle,
      details: [
        'Configures class code and duration',
        'Chooses cue frequency profile (e.g. 5–15 min intervals or custom)',
        'Selects harmonic chime sound',
      ],
    },
    {
      step: 2,
      title: 'System sends random audio cues',
      subtitle: 'Unpredictable Audio Triggering',
      desc: 'At mathematically randomized, non-periodic moments, the browser synthesizes a brief 0.8-second pleasant acoustic cue. The unpredictability ensures students cannot schedule periodic check-ins.',
      icon: Volume2,
      details: [
        'Web Audio API sine/triangle synthesis',
        'Audible only on student headphones/speakers',
        'Does not disrupt speaker voice or presentation audio',
      ],
    },
    {
      step: 3,
      title: 'Student responds via button or key',
      subtitle: 'Effortless Micro-Interaction',
      desc: 'A student actively listening immediately hears the chime. They tap the Spacebar, Enter, or click the "I’m Listening" button. This takes less than 2 seconds and does not distract from lecture notes.',
      icon: Keyboard,
      details: [
        'Accessible keyboard shortcuts (Space / Enter)',
        'Zero camera or facial exposure',
        'Immediate local confirmation feedback',
      ],
    },
    {
      step: 4,
      title: 'AttentionGuard generates attention score',
      subtitle: 'Objective Latency Analytics',
      desc: 'The system computes millisecond response latency, verifies participation rate, and updates the instructor dashboard with constructive, respectful indicators like "Attentive" or "Needs Attention Check".',
      icon: LineChart,
      details: [
        'Sub-second precision logging',
        'Neutral wording (never "not listening")',
        'Auditable aggregate attendance reports',
      ],
    },
  ];

  const handleSimulatePress = () => {
    setTestPressed(true);
    const mockLatency = Number((1.1 + Math.random() * 0.9).toFixed(2));
    setTestResponseTime(mockLatency);
    setTimeout(() => {
      setTestPressed(false);
      setTestResponseTime(null);
    }, 3000);
  };

  return (
    <section className="py-16 md:py-24 border-t border-slate-800/80 bg-slate-900/40">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center space-y-3 mb-12">
          <div className="text-xs font-semibold uppercase tracking-wider text-indigo-400">
            A Transparent 4-Step Architecture
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
            How The System Works
          </h2>
          <p className="text-sm sm:text-base text-slate-400 leading-relaxed">
            From lecture start to automated engagement reports — zero camera stream, zero facial recognition.
          </p>
        </div>

        {/* Step indicator selector */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 max-w-4xl mx-auto mb-10">
          {steps.map((s) => {
            const Icon = s.icon;
            const isCurrent = activeStep === s.step;
            return (
              <button
                key={s.step}
                onClick={() => setActiveStep(s.step)}
                className={`p-4 rounded-xl text-left border transition-all ${
                  isCurrent
                    ? 'bg-indigo-600/15 border-indigo-500/80 text-white shadow-lg shadow-indigo-600/10'
                    : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-xs font-bold ${isCurrent ? 'text-indigo-400' : 'text-slate-500'}`}>
                    STEP 0{s.step}
                  </span>
                  <Icon className={`h-4 w-4 ${isCurrent ? 'text-indigo-400' : 'text-slate-500'}`} />
                </div>
                <div className="text-sm font-semibold truncate text-white">{s.title.split(' ')[0]} {s.title.split(' ')[1]}</div>
              </button>
            );
          })}
        </div>

        {/* Active Step Showcase Card */}
        {(() => {
          const current = steps[activeStep - 1];
          const Icon = current.icon;
          return (
            <div className="max-w-4xl mx-auto rounded-2xl border border-slate-800 bg-slate-950 p-6 md:p-8 shadow-xl">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
                <div className="md:col-span-7 space-y-4">
                  <div className="inline-flex items-center gap-2 text-xs font-semibold text-indigo-400 bg-indigo-500/10 px-2.5 py-1 rounded-md border border-indigo-500/20">
                    <Icon className="h-3.5 w-3.5" />
                    <span>Step {current.step}: {current.subtitle}</span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-bold text-white leading-snug">
                    {current.title}
                  </h3>

                  <p className="text-sm text-slate-300 leading-relaxed">
                    {current.desc}
                  </p>

                  <div className="space-y-2 pt-2">
                    {current.details.map((detail, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-slate-400">
                        <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{detail}</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-4 flex items-center gap-4">
                    <button
                      onClick={() => setActiveStep(prev => (prev < 4 ? prev + 1 : 1))}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-400 hover:text-indigo-300 transition-colors"
                    >
                      <span>{activeStep < 4 ? `Proceed to Step 0${activeStep + 1}` : 'Start Over with Step 01'}</span>
                      <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>

                {/* Interactive Sandbox for this step */}
                <div className="md:col-span-5 bg-slate-900/90 rounded-xl border border-slate-800 p-5 space-y-4">
                  <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 border-b border-slate-800 pb-2 flex items-center justify-between">
                    <span>Interactive Micro-Sandbox</span>
                    <span className="text-emerald-400 text-[10px]">Ready</span>
                  </div>

                  {activeStep === 1 && (
                    <div className="space-y-3 text-xs">
                      <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                        <div className="font-semibold text-white mb-1">Classroom: CS-301</div>
                        <div className="text-slate-400">Instructor: Dr. Priya Sharma</div>
                        <div className="text-slate-400">10 Enrolled Students Connected</div>
                      </div>
                      <button
                        onClick={() => setCurrentView('teacher')}
                        className="w-full py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-medium transition-colors text-center"
                      >
                        Open Teacher Console
                      </button>
                    </div>
                  )}

                  {activeStep === 2 && (
                    <div className="space-y-3">
                      <div className="text-xs text-slate-300">Choose acoustic cue to audition:</div>
                      <div className="space-y-1.5">
                        {(['gentle_chime', 'sonar_ping', 'warm_pulse'] as CueType[]).map((cue) => (
                          <button
                            key={cue}
                            onClick={() => {
                              setSampleCue(cue);
                              testAudioCue(cue);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium border transition-colors ${
                              sampleCue === cue
                                ? 'bg-indigo-600/20 border-indigo-500 text-indigo-200'
                                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                            }`}
                          >
                            <span className="capitalize">{cue.replace('_', ' ')}</span>
                            <Volume2 className="h-3.5 w-3.5 text-indigo-400" />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {activeStep === 3 && (
                    <div className="space-y-3 text-center">
                      <div className="text-xs text-slate-400">
                        Try pressing the button or hit Spacebar:
                      </div>
                      <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                        {testPressed ? (
                          <div className="py-2 text-emerald-400 font-semibold text-xs space-y-1">
                            <div>Response recorded ✓</div>
                            <div className="text-slate-300 text-[11px] font-mono">
                              Latency: {testResponseTime} seconds
                            </div>
                          </div>
                        ) : (
                          <button
                            onClick={handleSimulatePress}
                            className="w-full py-3 rounded-lg bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-bold text-xs shadow-md transition-all active:scale-95"
                          >
                            I'M LISTENING (SPACEBAR)
                          </button>
                        )}
                      </div>
                    </div>
                  )}

                  {activeStep === 4 && (
                    <div className="space-y-2.5 text-xs">
                      <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex justify-between items-center">
                        <span className="text-slate-400">Response Rate</span>
                        <span className="font-mono text-emerald-400 font-semibold">90%</span>
                      </div>
                      <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex justify-between items-center">
                        <span className="text-slate-400">Avg Latency</span>
                        <span className="font-mono text-indigo-300 font-semibold">1.4 sec</span>
                      </div>
                      <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex justify-between items-center">
                        <span className="text-slate-400">Class Attention</span>
                        <span className="font-mono text-indigo-400 font-semibold">88% (Attentive)</span>
                      </div>
                      <button
                        onClick={() => setCurrentView('live-demo')}
                        className="w-full py-2 mt-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium transition-colors"
                      >
                        Launch Live Demo
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })()}
      </div>
    </section>
  );
};
