import React from 'react';
import { useSession } from '../../context/SessionContext';
import { ArrowRight, Volume2, ShieldCheck, UserCheck, Activity, Laptop, Bell, Sparkles, BookOpen } from 'lucide-react';

export const HeroSection: React.FC = () => {
  const { setCurrentView, testAudioCue, triggerAttentionCheck, activeCheck } = useSession();

  return (
    <section className="relative overflow-hidden pt-12 pb-20 md:pt-20 md:pb-28">
      {/* Background glow effects */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-indigo-600/15 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute top-1/3 right-10 w-[300px] h-[250px] bg-violet-600/10 blur-[90px] rounded-full pointer-events-none" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-6">
          {/* Subtle announcement kicker */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900/90 border border-slate-700/60 text-xs text-slate-300">
            <span className="flex h-2 w-2 rounded-full bg-emerald-400" />
            <span className="font-medium text-emerald-400">100% Non-Camera Verification</span>
            <span className="text-slate-500">·</span>
            <span>Built-In Autonomous Classroom Platform</span>
          </div>

          {/* Main Headline */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.1] text-balance">
            Are They Really Listening?
          </h1>

          {/* Subtitle */}
          <p className="text-lg sm:text-xl text-slate-300 font-normal leading-relaxed text-balance max-w-2xl mx-auto">
            AttentionGuard verifies student attention during online classes without cameras, facial recognition, or invasive video monitoring.
          </p>

          {/* CTAs */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={() => setCurrentView('teacher')}
              className="inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-indigo-600/25 hover:bg-indigo-500 hover:shadow-indigo-500/35 transition-all active:scale-95"
            >
              <span>Teacher Dashboard</span>
              <ArrowRight className="h-4 w-4" />
            </button>

            <button
              onClick={() => setCurrentView('student')}
              className="inline-flex items-center gap-2 rounded-lg bg-slate-800/90 border border-slate-700/80 px-5 py-3 text-sm font-semibold text-slate-200 hover:bg-slate-700/90 hover:text-white transition-all active:scale-95"
            >
              <UserCheck className="h-4 w-4 text-indigo-400" />
              <span>Join as Student</span>
            </button>

            <button
              onClick={() => setCurrentView('classroom')}
              className="inline-flex items-center gap-2 rounded-lg bg-emerald-950/60 border border-emerald-700/60 px-5 py-3 text-sm font-semibold text-emerald-300 hover:bg-emerald-900/60 hover:text-white transition-all active:scale-95"
            >
              <BookOpen className="h-4 w-4 text-emerald-400" />
              <span>Enter Online Classroom</span>
            </button>

            <button
              onClick={() => setCurrentView('live-demo')}
              className="inline-flex items-center gap-2 rounded-lg bg-violet-950/60 border border-violet-700/50 px-5 py-3 text-sm font-semibold text-violet-200 hover:bg-violet-900/60 hover:text-white transition-all active:scale-95"
            >
              <Sparkles className="h-4 w-4 text-violet-400" />
              <span>Try Live Demo</span>
            </button>
          </div>

          {/* Audio preview test chip */}
          <div className="pt-2 flex items-center justify-center gap-2 text-xs text-slate-400">
            <span>Curious what an audio cue sounds like?</span>
            <button
              onClick={() => testAudioCue('gentle_chime')}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-indigo-300 font-medium transition-colors border border-slate-700"
            >
              <Volume2 className="h-3 w-3" />
              <span>Play Sample Chime</span>
            </button>
          </div>
        </div>

        {/* Visual Illustration: Online Class → Random Audio Cue → Student Response → Attention Score */}
        <div className="mt-14 max-w-5xl mx-auto">
          <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-6 md:p-8 backdrop-blur-sm shadow-xl">
            <div className="text-center mb-6">
              <span className="text-xs font-semibold uppercase tracking-wider text-indigo-400">
                The Non-Invasive Verification Flow
              </span>
              <h2 className="text-xl font-bold text-white mt-1">
                How Micro-Interactions Verify Presence in Real-Time
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 relative">
              {/* Step 1 */}
              <div className="flex flex-col items-center text-center p-4 rounded-xl bg-slate-950/80 border border-slate-800/80 hover:border-indigo-500/40 transition-colors">
                <div className="h-12 w-12 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400 mb-3">
                  <Laptop className="h-6 w-6" />
                </div>
                <div className="text-xs font-semibold text-indigo-400 mb-1">01. Live Class</div>
                <h3 className="text-sm font-semibold text-white mb-1">Online Class In Progress</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Lectures proceed smoothly in the built-in online classroom without forced webcams.
                </p>
              </div>

              {/* Step 2 */}
              <div className="flex flex-col items-center text-center p-4 rounded-xl bg-slate-950/80 border border-slate-800/80 hover:border-violet-500/40 transition-colors">
                <div className="h-12 w-12 rounded-xl bg-violet-500/10 border border-violet-500/30 flex items-center justify-center text-violet-400 mb-3">
                  <Bell className="h-6 w-6" />
                </div>
                <div className="text-xs font-semibold text-violet-400 mb-1">02. Audio Cue</div>
                <h3 className="text-sm font-semibold text-white mb-1">Randomized Chime</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Unpredictable intervals emit a pleasant harmonic tone audible only to students.
                </p>
              </div>

              {/* Step 3 */}
              <div className="flex flex-col items-center text-center p-4 rounded-xl bg-slate-950/80 border border-slate-800/80 hover:border-cyan-500/40 transition-colors">
                <div className="h-12 w-12 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-3">
                  <UserCheck className="h-6 w-6" />
                </div>
                <div className="text-xs font-semibold text-cyan-400 mb-1">03. Keypress / Click</div>
                <h3 className="text-sm font-semibold text-white mb-1">Instant Student Tap</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Active student presses Spacebar, Enter, or clicks "I'm Listening" in 1–2 seconds.
                </p>
              </div>

              {/* Step 4 */}
              <div className="flex flex-col items-center text-center p-4 rounded-xl bg-slate-950/80 border border-slate-800/80 hover:border-emerald-500/40 transition-colors">
                <div className="h-12 w-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mb-3">
                  <Activity className="h-6 w-6" />
                </div>
                <div className="text-xs font-semibold text-emerald-400 mb-1">04. Live Analytics</div>
                <h3 className="text-sm font-semibold text-white mb-1">Attention Score Generated</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Teacher receives aggregate latency metrics with neutral, respectful status indicators.
                </p>
              </div>
            </div>

            {/* Quick interactive test strip */}
            <div className="mt-6 pt-5 border-t border-slate-800/70 flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-950/50 p-4 rounded-xl">
              <div className="flex items-center gap-3">
                <div className="h-8 w-8 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-400">
                  <ShieldCheck className="h-4 w-4" />
                </div>
                <div className="text-left">
                  <div className="text-xs font-semibold text-white">Experience it right now</div>
                  <div className="text-xs text-slate-400">Send an attention check across the live room state</div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => triggerAttentionCheck()}
                  className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white transition-colors shadow-sm"
                >
                  {activeCheck ? 'Cue Currently Active' : 'Send Test Attention Cue'}
                </button>
                <button
                  onClick={() => setCurrentView('live-demo')}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 transition-colors"
                >
                  View Split Screen
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Hero Visual Asset from Image Generation */}
        <div className="mt-12 max-w-5xl mx-auto rounded-2xl overflow-hidden border border-slate-800/90 shadow-2xl relative group">
          <img
            src="/src/assets/images/hero_concept_1790662072141.jpg"
            alt="AttentionGuard sound wave and privacy verification system render"
            className="w-full h-64 sm:h-80 md:h-96 object-cover object-center filter brightness-95 group-hover:scale-102 transition-transform duration-700"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
          <div className="absolute bottom-6 left-6 right-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <div className="text-xs font-semibold uppercase tracking-wider text-indigo-400 mb-1">
                Ethical EdTech Paradigm
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-white">
                Verification Through Active Response, Not Video Surveillance
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 max-w-xl mt-1">
                Preserve student dignity, eliminate camera anxiety, and drastically reduce bandwidth consumption while gaining truthful attendance analytics.
              </p>
            </div>
            <button
              onClick={() => setCurrentView('how-it-works')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-300 hover:text-white whitespace-nowrap bg-slate-900/80 px-3 py-2 rounded-lg border border-slate-700"
            >
              <span>Explore The Protocol</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
