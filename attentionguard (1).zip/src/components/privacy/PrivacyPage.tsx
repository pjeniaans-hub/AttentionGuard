import React from 'react';
import { useSession } from '../../context/SessionContext';
import {
  ShieldCheck,
  VideoOff,
  EyeOff,
  MicOff,
  Lock,
  CheckCircle2,
  XCircle,
  FileText,
  Server,
  HeartHandshake,
} from 'lucide-react';

export const PrivacyPage: React.FC = () => {
  const { setCurrentView } = useSession();

  const comparisonRows = [
    {
      feature: 'Camera Access Requested',
      proctor: 'Mandatory 1080p continuous video feed',
      attentionGuard: 'NEVER requested (0 bytes video)',
    },
    {
      feature: 'Facial & Emotion Analysis',
      proctor: 'Continuous AI gaze & head pose tracking',
      attentionGuard: 'NONE (100% Biometric-free)',
    },
    {
      feature: 'Room / Living Space Surveillance',
      proctor: 'Room scans, bedroom & family exposure',
      attentionGuard: 'Zero visual access to student space',
    },
    {
      feature: 'Microphone Recording',
      proctor: 'Continuous ambient room audio capture',
      attentionGuard: 'Zero ambient audio recording',
    },
    {
      feature: 'Bandwidth Requirement',
      proctor: 'High (1.5 - 3.5 Mbps per student)',
      attentionGuard: 'Ultra-low (< 2 Kbps lightweight signal)',
    },
    {
      feature: 'Student Dignity & Stress',
      proctor: 'High anxiety, self-consciousness & fatigue',
      attentionGuard: 'Calm, respectful micro-interaction',
    },
    {
      feature: 'Bias & Inequity',
      proctor: 'Penalizes dark skin tones & neurodivergence',
      attentionGuard: 'Objective acoustic latency with flexible windows',
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950 py-12 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-5xl space-y-12">
        {/* Hero Section */}
        <div className="text-center space-y-4 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/70 border border-emerald-800/60 text-xs font-semibold text-emerald-400">
            <ShieldCheck className="h-4 w-4" />
            <span>Privacy Architecture & Ethical Commitment</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight text-balance">
            AttentionGuard Does Not Use Cameras Or Facial Recognition
          </h1>

          <p className="text-base sm:text-lg text-slate-300 leading-relaxed text-balance">
            We believe verifying student engagement should never come at the cost of personal dignity, home privacy, or algorithmic surveillance.
          </p>

          {/* Core 4 Privacy Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4">
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-center space-y-1">
              <VideoOff className="h-5 w-5 text-emerald-400 mx-auto" />
              <div className="text-xs font-bold text-white">No Camera Required</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-center space-y-1">
              <EyeOff className="h-5 w-5 text-emerald-400 mx-auto" />
              <div className="text-xs font-bold text-white">No Facial Recognition</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-center space-y-1">
              <Lock className="h-5 w-5 text-emerald-400 mx-auto" />
              <div className="text-xs font-bold text-white">No Video Monitoring</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-center space-y-1">
              <ShieldCheck className="h-5 w-5 text-emerald-400 mx-auto" />
              <div className="text-xs font-bold text-white">Privacy-First Design</div>
            </div>
          </div>
        </div>

        {/* Visual Privacy Shield Illustration & Statement */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 md:p-8 overflow-hidden shadow-2xl">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            <div className="md:col-span-4 flex justify-center">
              <div className="relative group">
                <img
                  src="/src/assets/images/privacy_shield_1790662088928.jpg"
                  alt="AttentionGuard privacy shield protection"
                  className="w-56 h-56 rounded-2xl object-cover border border-slate-700/80 shadow-2xl shadow-indigo-600/10 group-hover:scale-102 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-t from-slate-950/60 via-transparent to-transparent pointer-events-none" />
              </div>
            </div>

            <div className="md:col-span-8 space-y-4">
              <h2 className="text-2xl font-bold text-white">
                What AttentionGuard Collects — And What We Never Touch
              </h2>
              <p className="text-sm text-slate-300 leading-relaxed">
                Traditional proctoring and attentiveness tools record bedroom webcams, track pupil dilation, and analyze micro-expressions with error-prone neural nets. AttentionGuard fundamentally rejects this invasive paradigm.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-3.5 rounded-xl bg-slate-950/80 border border-emerald-900/40 space-y-2">
                  <div className="text-xs font-bold text-emerald-400 flex items-center gap-1.5 uppercase tracking-wide">
                    <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                    <span>What We Process</span>
                  </div>
                  <ul className="text-xs text-slate-300 space-y-1.5">
                    <li>• Synthetic audio cues sent by system</li>
                    <li>• Spacebar, Enter, or Click response events</li>
                    <li>• Response timestamp & latency (seconds)</li>
                    <li>• Session interaction rate aggregate</li>
                  </ul>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950/80 border border-rose-900/40 space-y-2">
                  <div className="text-xs font-bold text-rose-400 flex items-center gap-1.5 uppercase tracking-wide">
                    <XCircle className="h-4 w-4 text-rose-400" />
                    <span>Strictly Prohibited</span>
                  </div>
                  <ul className="text-xs text-slate-300 space-y-1.5">
                    <li>• Webcams and video stream transmission</li>
                    <li>• Facial recognition and gaze geometry</li>
                    <li>• Ambient microphone room recording</li>
                    <li>• Screen recording or tab scraping</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Privacy Comparison Table */}
        <div className="space-y-4">
          <div className="text-center sm:text-left">
            <h3 className="text-xl font-bold text-white">
              Architectural Comparison: Camera Systems vs. AttentionGuard
            </h3>
            <p className="text-xs sm:text-sm text-slate-400">
              Why active acoustic verification outclasses intrusive video monitoring in every ethical dimension.
            </p>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-900/60 overflow-hidden shadow-lg">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[11px] font-semibold border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4 sm:px-6">Privacy Dimension</th>
                  <th className="py-3 px-4 text-rose-400 font-semibold">Webcam / AI Gaze Monitors</th>
                  <th className="py-3 px-4 text-emerald-400 font-semibold">AttentionGuard</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70">
                {comparisonRows.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-3 px-4 sm:px-6 font-semibold text-slate-200">
                      {row.feature}
                    </td>
                    <td className="py-3 px-4 text-rose-300">
                      {row.proctor}
                    </td>
                    <td className="py-3 px-4 text-emerald-300 font-medium">
                      {row.attentionGuard}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Data Retention & Student Rights */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/50 space-y-2.5">
            <Server className="h-5 w-5 text-indigo-400" />
            <h4 className="text-sm font-bold text-white">Zero Cloud Video Storage</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Because video is never captured in the first place, there is zero risk of student bedroom footage leaking, being subpoenaed, or being hacked.
            </p>
          </div>

          <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/50 space-y-2.5">
            <HeartHandshake className="h-5 w-5 text-indigo-400" />
            <h4 className="text-sm font-bold text-white">Digital Equity & Inclusivity</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Students without dedicated study spaces or with family members nearby can participate with dignity without feeling ashamed of their surroundings.
            </p>
          </div>

          <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/50 space-y-2.5">
            <FileText className="h-5 w-5 text-indigo-400" />
            <h4 className="text-sm font-bold text-white">Auditable, Neutral Logs</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Attendance records only reflect timestamped keypresses. Neutral terminology protects student-teacher rapport without punitive accusations.
            </p>
          </div>
        </div>

        {/* Action Prompt */}
        <div className="rounded-xl border border-indigo-900/40 bg-gradient-to-r from-indigo-950/40 to-slate-900 p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h4 className="text-base font-bold text-white">Experience privacy-first presence in action</h4>
            <p className="text-xs text-slate-400">Launch our interactive live demo to see how simple and respectful verification is.</p>
          </div>
          <button
            onClick={() => setCurrentView('live-demo')}
            className="px-4 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-colors shadow-md whitespace-nowrap"
          >
            Launch Live Demo
          </button>
        </div>
      </div>
    </div>
  );
};
