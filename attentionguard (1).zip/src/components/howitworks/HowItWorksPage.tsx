import React, { useState } from 'react';
import { useSession } from '../../context/SessionContext';
import {
  PlayCircle,
  Volume2,
  Keyboard,
  LineChart,
  Calculator,
  Sliders,
  CheckCircle,
  HelpCircle,
  Zap,
} from 'lucide-react';
import { getSingleInteractionPoints, categorizeResponseTime } from '../../utils/scoring';

export const HowItWorksPage: React.FC = () => {
  const { setCurrentView, testAudioCue, triggerAttentionCheck } = useSession();

  // Interactive latency testing slider
  const [testSliderTime, setTestSliderTime] = useState<number>(1.4);

  const points = getSingleInteractionPoints(testSliderTime);
  const category = categorizeResponseTime(testSliderTime);

  return (
    <div className="min-h-screen bg-slate-950 py-12 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-5xl space-y-14">
        {/* Header */}
        <div className="text-center space-y-4 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-950/70 border border-indigo-800/60 text-xs font-semibold text-indigo-400">
            <LineChart className="h-3.5 w-3.5" />
            <span>Operational Mechanics & Transparent Algorithms</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            How AttentionGuard Operates
          </h1>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl mx-auto">
            A deep-dive into unpredictable interval mathematics, browser-synthesized audio frequencies, and fair latency-based attention formulas.
          </p>
        </div>

        {/* 4 Steps In Detail */}
        <div className="space-y-6">
          <h2 className="text-xl font-bold text-white border-b border-slate-800 pb-3">
            The 4-Step Verification Lifecycle
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Step 1 */}
            <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/60 space-y-3">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center font-bold font-mono">
                  01
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Teacher Starts Online Session</h3>
                  <span className="text-xs text-indigo-400 font-medium">Session Initialization</span>
                </div>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                The educator initiates the AttentionGuard built-in online classroom session. Students connect directly in their browser without installing extensions or granting webcam rights.
              </p>
            </div>

            {/* Step 2 */}
            <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/60 space-y-3">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-violet-600/20 text-violet-400 flex items-center justify-center font-bold font-mono">
                  02
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Independent Random Audio Cues</h3>
                  <span className="text-xs text-violet-400 font-medium">Independent Schedule Per Student</span>
                </div>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Each student receives an independent random cue approximately once every 2 minutes (90–150 seconds, or 10–20 seconds in Demo Mode). Because every student has an independent timer, cues are never synchronized together.
              </p>
            </div>

            {/* Step 3 */}
            <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/60 space-y-3">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-cyan-600/20 text-cyan-400 flex items-center justify-center font-bold font-mono">
                  03
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Student Responds With 1 Tap</h3>
                  <span className="text-xs text-cyan-400 font-medium">Effortless Keypress</span>
                </div>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Upon hearing the cue, the student presses the Spacebar, Enter, or clicks "I’m Listening". The micro-interaction takes &lt; 2 seconds, producing instant visual and acoustic confirmation without interrupting their note-taking.
              </p>
            </div>

            {/* Step 4 */}
            <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/60 space-y-3">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center font-bold font-mono">
                  04
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Attention Score Generated</h3>
                  <span className="text-xs text-emerald-400 font-medium">Transparent Telemetry</span>
                </div>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                The system calculates the exact response latency and updates the instructor's dashboard. Respectful, non-accusatory terminology is used exclusively: "Attentive", "Active", or "Needs Attention Check".
              </p>
            </div>
          </div>
        </div>

        {/* Smart Attention Scoring Logic Breakdown */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-6 md:p-8 space-y-6">
          <div className="flex items-center gap-2">
            <Calculator className="h-5 w-5 text-indigo-400" />
            <h2 className="text-xl font-bold text-white">Smart Attention Scoring Logic</h2>
          </div>

          <p className="text-sm text-slate-300 leading-relaxed">
            Our scoring system is completely transparent. It measures interaction response behavior, not cognitive inner thoughts.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
              <div className="text-xs font-bold text-emerald-400 uppercase">Strong Response</div>
              <div className="text-xl font-bold font-mono text-white">≤ 2.0 sec</div>
              <div className="text-xs font-mono text-emerald-400 font-semibold">95 - 100 points</div>
              <p className="text-[11px] text-slate-400 pt-1">
                Immediate confirmation reflecting active real-time focus.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
              <div className="text-xs font-bold text-indigo-400 uppercase">Normal Response</div>
              <div className="text-xl font-bold font-mono text-white">2.1s - 5.0s</div>
              <div className="text-xs font-mono text-indigo-400 font-semibold">75 - 94 points</div>
              <p className="text-[11px] text-slate-400 pt-1">
                Healthy response window while jotting notes or reading slides.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
              <div className="text-xs font-bold text-amber-400 uppercase">Delayed Response</div>
              <div className="text-xl font-bold font-mono text-white">&gt; 5.0 sec</div>
              <div className="text-xs font-mono text-amber-400 font-semibold">30 - 74 points</div>
              <p className="text-[11px] text-slate-400 pt-1">
                Slightly delayed; student may have navigated to another tab.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
              <div className="text-xs font-bold text-rose-400 uppercase">Missed Response</div>
              <div className="text-xl font-bold font-mono text-white">&gt; 10.0 sec (Timeout)</div>
              <div className="text-xs font-mono text-rose-400 font-semibold">0 points</div>
              <p className="text-[11px] text-slate-400 pt-1">
                Prompt elapsed without keypress; labeled as "Did not respond".
              </p>
            </div>
          </div>

          {/* Interactive Calculator Slider */}
          <div className="p-5 rounded-xl bg-slate-950 border border-slate-800/80 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Sliders className="h-4 w-4 text-indigo-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Test the Latency Formula In Real Time
                </span>
              </div>
              <div className="text-xs font-mono text-slate-400">
                Simulated Latency: <span className="text-white font-bold">{testSliderTime.toFixed(1)}s</span>
              </div>
            </div>

            <input
              type="range"
              min="0.5"
              max="11.0"
              step="0.1"
              value={testSliderTime}
              onChange={(e) => setTestSliderTime(parseFloat(e.target.value))}
              className="w-full accent-indigo-500 cursor-pointer"
            />

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-center text-xs">
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Speed Category</span>
                <span className="text-sm font-bold capitalize text-white">{category} Response</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Calculated Points</span>
                <span className="text-sm font-bold font-mono text-indigo-300">{points} / 100</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Resulting Status Label</span>
                <span className={`text-sm font-bold ${points >= 85 ? 'text-emerald-400' : points >= 70 ? 'text-indigo-300' : 'text-amber-400'}`}>
                  {points >= 85 ? 'Attentive' : points >= 70 ? 'Active' : 'Needs attention check'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* The Non-Camera Guarantee */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-6 md:p-8 space-y-4">
          <h3 className="text-lg font-bold text-white">Why Micro-Interactions Outperform Webcams</h3>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Educational psychologists note that forcing webcams induces cognitive overload from self-view ("mirror anxiety") without ensuring listening comprehension. A student can stare directly into a camera while mentally daydreaming.
          </p>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Conversely, reacting to an unpredictable acoustic cue requires active real-time listening through headphones or speakers. It verifies presence with zero privacy invasion.
          </p>
          <div className="pt-2">
            <button
              onClick={() => setCurrentView('live-demo')}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md transition-colors"
            >
              <Zap className="h-3.5 w-3.5" />
              <span>Try Live Verification Demo</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
