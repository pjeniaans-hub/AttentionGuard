import React, { useState } from 'react';
import { useSession } from '../../context/SessionContext';
import {
  Volume2,
  Play,
  RotateCcw,
  Zap,
  Clock,
  AlertCircle,
  CheckCircle2,
  Users,
  Activity,
  Headphones,
  Laptop,
  ArrowRight,
  Sparkles,
  BookOpen,
  EyeOff,
} from 'lucide-react';
import { CueType } from '../../types';

export const LiveDemoPage: React.FC = () => {
  const {
    session,
    students,
    activeCheck,
    checkTimeRemaining,
    hasStudentResponded,
    studentResponseTime,
    triggerAttentionCheck,
    handleStudentResponse,
    simulateDemoScenario,
    resetDemoData,
    selectedCueType,
    setSelectedCueType,
    testAudioCue,
    startSession,
    endSession,
    setCurrentView,
  } = useSession();

  const [activeTab, setActiveTab] = useState<'split' | 'teacher' | 'student'>('split');

  // Statistics
  const totalStudents = students.length;
  const attentiveCount = students.filter(s => s.currentStatus === 'attentive').length;
  const avgScore = totalStudents > 0
    ? Math.round(students.reduce((a, b) => a + b.attentionScore, 0) / totalStudents)
    : 0;

  return (
    <div className="min-h-screen bg-slate-950 py-8 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl space-y-6">
        {/* Hackathon Header & Walkthrough Guide */}
        <div className="rounded-2xl border border-indigo-900/50 bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 p-6 shadow-xl">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-indigo-400 bg-indigo-500/10 px-2.5 py-0.5 rounded-md border border-indigo-500/20">
                <Sparkles className="h-3.5 w-3.5" />
                <span>Hackathon Live Interactive Sandbox</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                Standalone Online Classroom Verification
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
                Test the non-camera attention verification flow from both Teacher and Student sides side-by-side. Hear the Web Audio tone and watch the latency analytics update live.
              </p>
            </div>

            {/* View Mode Switcher */}
            <div className="flex items-center gap-2 bg-slate-950/80 p-1.5 rounded-xl border border-slate-800 shrink-0">
              <button
                onClick={() => setActiveTab('split')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  activeTab === 'split' ? 'bg-indigo-600 text-white font-semibold shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                Split Screen (Both Views)
              </button>
              <button
                onClick={() => setActiveTab('teacher')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  activeTab === 'teacher' ? 'bg-indigo-600 text-white font-semibold shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                Teacher Only
              </button>
              <button
                onClick={() => setActiveTab('student')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  activeTab === 'student' ? 'bg-indigo-600 text-white font-semibold shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                Student Only
              </button>
            </div>
          </div>

          {/* Hackathon Demo Flow Walkthrough Bar */}
          <div className="mt-5 pt-4 border-t border-slate-800/80 flex flex-wrap items-center gap-2 text-xs text-slate-400">
            <span className="font-semibold text-slate-200">Demo Flow:</span>
            <span className="text-indigo-300">Teacher starts session</span>
            <ArrowRight className="h-3 w-3 text-slate-600" />
            <span className="text-indigo-300">Student joins</span>
            <ArrowRight className="h-3 w-3 text-slate-600" />
            <span className="text-indigo-300">Random cue plays</span>
            <ArrowRight className="h-3 w-3 text-slate-600" />
            <span className="text-indigo-300">Student responds</span>
            <ArrowRight className="h-3 w-3 text-slate-600" />
            <span className="text-emerald-400 font-semibold">Dashboard updates</span>
          </div>
        </div>

        {/* Global Demo Action Bar */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => triggerAttentionCheck()}
              disabled={activeCheck !== null}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all shadow-md active:scale-95 ${
                activeCheck
                  ? 'bg-amber-600 text-white cursor-not-allowed opacity-80'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30'
              }`}
            >
              <Volume2 className="h-4 w-4" />
              <span>{activeCheck ? `Audio Cue Active (${checkTimeRemaining}s)` : 'Trigger Audio Cue Now'}</span>
            </button>

            {/* Quick response demo shortcut */}
            <button
              onClick={() => simulateDemoScenario('quick')}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-700/50 text-emerald-300 text-xs font-semibold transition-colors shadow-sm"
              title="Demonstrates a student responding in 1.2 seconds"
            >
              <Zap className="h-3.5 w-3.5" />
              <span>Quick Response (1.2s)</span>
            </button>

            {/* Delayed/Missed demo shortcut */}
            <button
              onClick={() => simulateDemoScenario('delayed')}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-amber-950/60 hover:bg-amber-900/60 border border-amber-700/50 text-amber-300 text-xs font-semibold transition-colors shadow-sm"
              title="Demonstrates a student responding with 6.5s delay"
            >
              <Clock className="h-3.5 w-3.5" />
              <span>Delayed Response (6.5s)</span>
            </button>

            <button
              onClick={() => simulateDemoScenario('missed')}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-rose-950/60 hover:bg-rose-900/60 border border-rose-700/50 text-rose-300 text-xs font-semibold transition-colors shadow-sm"
              title="Demonstrates student failing to respond before timeout"
            >
              <AlertCircle className="h-3.5 w-3.5" />
              <span>Missed Response (Timeout)</span>
            </button>
          </div>

          <div className="flex items-center gap-3">
            <select
              value={selectedCueType}
              onChange={(e) => {
                const val = e.target.value as CueType;
                setSelectedCueType(val);
                testAudioCue(val);
              }}
              className="bg-slate-950 border border-slate-800 rounded-md px-2.5 py-1.5 text-xs text-slate-200"
            >
              <option value="gentle_chime">Gentle Chime</option>
              <option value="sonar_ping">Sonar Ping</option>
              <option value="warm_pulse">Warm Pulse</option>
            </select>

            <button
              onClick={resetDemoData}
              className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-colors"
              title="Reset test data"
            >
              <RotateCcw className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* AttentionGuard Classroom Launch Bar */}
        <div className="rounded-2xl border border-indigo-900/50 bg-slate-900/90 p-5 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center shrink-0">
              <BookOpen className="h-5 w-5" />
            </div>
            <div>
              <div className="text-sm font-bold text-white flex items-center gap-2">
                <span>Autonomous Online Classroom Active</span>
                <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              </div>
              <p className="text-xs text-slate-400">
                Experience the integrated virtual whiteboard, student roster, live chat, and non-camera verification in one place.
              </p>
            </div>
          </div>

          <button
            onClick={() => setCurrentView('classroom')}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-xs font-bold shadow-md shadow-indigo-600/25 transition-all active:scale-95 whitespace-nowrap"
          >
            <BookOpen className="h-4 w-4" />
            <span>Open Online Classroom Screen</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>

        {/* Split Screen Grid */}
        <div className={`grid gap-6 ${activeTab === 'split' ? 'grid-cols-1 lg:grid-cols-12' : 'grid-cols-1'}`}>
          {/* ================= TEACHER PERSPECTIVE ================= */}
          {(activeTab === 'split' || activeTab === 'teacher') && (
            <div className={`${activeTab === 'split' ? 'lg:col-span-7' : 'w-full'} space-y-4`}>
              <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5 shadow-lg space-y-4">
                {/* Header */}
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <div className="h-8 w-8 rounded-lg bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
                      <Laptop className="h-4 w-4" />
                    </div>
                    <div>
                      <h2 className="text-sm font-bold text-white">Teacher Console View</h2>
                      <p className="text-[11px] text-slate-400">Class: {session.courseCode} · Live Attendance</p>
                    </div>
                  </div>

                  <button
                    onClick={() => setCurrentView('teacher')}
                    className="text-xs text-indigo-400 hover:text-indigo-300 font-medium"
                  >
                    Open Full Dashboard →
                  </button>
                </div>

                {/* Quick Stats Grid */}
                <div className="grid grid-cols-3 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-slate-400 block text-[10px]">Connected</span>
                    <span className="text-lg font-bold font-mono text-white">{totalStudents}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-slate-400 block text-[10px]">Attentive</span>
                    <span className="text-lg font-bold font-mono text-emerald-400">{attentiveCount}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-slate-400 block text-[10px]">Average Score</span>
                    <span className="text-lg font-bold font-mono text-indigo-300">{avgScore}%</span>
                  </div>
                </div>

                {/* Student Live Responses Table */}
                <div>
                  <div className="flex items-center justify-between text-xs font-semibold text-slate-400 mb-2">
                    <span>Live Student Roster</span>
                    <span>Last Response Latency</span>
                  </div>

                  <div className="space-y-1.5 max-h-80 overflow-y-auto pr-1">
                    {students.slice(0, 6).map((stu) => (
                      <div
                        key={stu.id}
                        className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950/80 border border-slate-800/80 text-xs"
                      >
                        <div>
                          <div className="font-semibold text-slate-200">{stu.name}</div>
                          <div className="text-[10px] text-slate-400">
                            Status:{' '}
                            <span className={stu.currentStatus === 'attentive' ? 'text-emerald-400' : stu.currentStatus === 'active' ? 'text-indigo-300' : 'text-amber-400'}>
                              {stu.currentStatus === 'attentive' ? 'Attentive' : stu.currentStatus === 'active' ? 'Active' : 'Needs attention check'}
                            </span>
                          </div>
                        </div>

                        <div className="text-right">
                          <div className="font-mono tabular-nums text-slate-200 font-medium">
                            {stu.lastResponseTime !== null ? `${stu.lastResponseTime.toFixed(1)}s` : 'Did not respond'}
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono">
                            Score: {stu.attentionScore}%
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Status bar */}
                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                  <span>No cameras accessed</span>
                  <span className="text-emerald-400 flex items-center gap-1 font-medium">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                    Real-time synchronized
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* ================= STUDENT PERSPECTIVE ================= */}
          {(activeTab === 'split' || activeTab === 'student') && (
            <div className={`${activeTab === 'split' ? 'lg:col-span-5' : 'w-full'} space-y-4`}>
              <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5 shadow-lg space-y-4 flex flex-col justify-between min-h-[460px]">
                {/* Header */}
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <div className="h-8 w-8 rounded-lg bg-violet-600/20 text-violet-400 flex items-center justify-center">
                      <Headphones className="h-4 w-4" />
                    </div>
                    <div>
                      <h2 className="text-sm font-bold text-white">Student Endpoint View</h2>
                      <p className="text-[11px] text-slate-400">Testing as Arun Kumar</p>
                    </div>
                  </div>

                  <button
                    onClick={() => setCurrentView('student')}
                    className="text-xs text-indigo-400 hover:text-indigo-300 font-medium"
                  >
                    Open Student View →
                  </button>
                </div>

                {/* Interactive Card Body */}
                <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
                  {activeCheck ? (
                    !hasStudentResponded ? (
                      <div className="space-y-5 animate-in zoom-in-95 duration-150 w-full">
                        <div className="relative mx-auto w-16 h-16 flex items-center justify-center">
                          <div className="absolute inset-0 rounded-full bg-indigo-500/20 animate-ping" />
                          <div className="h-14 w-14 rounded-full bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-600/40">
                            <Volume2 className="h-7 w-7" />
                          </div>
                        </div>

                        <div>
                          <h3 className="text-xl font-extrabold text-white">
                            Attention Check — Respond Now
                          </h3>
                          <p className="text-xs text-indigo-200 mt-0.5">
                            Audio cue sounded! Click below or press Spacebar
                          </p>
                          <p className="text-[11px] font-mono text-slate-400 mt-1">
                            Expires in {checkTimeRemaining}s
                          </p>
                        </div>

                        <button
                          onClick={() => handleStudentResponse()}
                          className="w-full py-3.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 transition-all active:scale-95 animate-pulse"
                        >
                          RESPOND NOW (SPACEBAR)
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-3 animate-in fade-in duration-200">
                        <div className="h-14 w-14 rounded-full bg-emerald-500/20 border border-emerald-500/50 flex items-center justify-center text-emerald-400 mx-auto">
                          <CheckCircle2 className="h-8 w-8" />
                        </div>
                        <h3 className="text-lg font-bold text-white">
                          Response recorded ✓
                        </h3>
                        <div className="text-xs font-mono text-emerald-400 font-semibold">
                          Response time: {studentResponseTime !== null ? `${studentResponseTime.toFixed(1)} seconds` : '1.3 seconds'}
                        </div>
                        <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                          Teacher dashboard on the left updated immediately with your presence verification.
                        </p>
                      </div>
                    )
                  ) : (
                    <div className="space-y-3">
                      <div className="h-14 w-14 rounded-2xl bg-slate-800 flex items-center justify-center text-slate-400 mx-auto">
                        <Headphones className="h-7 w-7" />
                      </div>
                      <h3 className="text-base font-semibold text-white">
                        Waiting for next attention check
                      </h3>
                      <p className="text-xs text-slate-400 max-w-xs mx-auto">
                        Click "Trigger Audio Cue Now" at the top to simulate Dr. Priya triggering an attention check.
                      </p>
                    </div>
                  )}
                </div>

                {/* Footer explanation */}
                <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-400 text-center">
                  <span>Student views zero surveillance widgets. Verification is non-invasive and instant.</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
