export type CueType = 'gentle_chime' | 'sonar_ping' | 'warm_pulse';

export type ResponseSpeedCategory = 'quick' | 'normal' | 'delayed' | 'missed';

export type StudentStatus = 'attentive' | 'active' | 'needs_attention';

export type VerificationScheduleMode = 'demo' | 'real'; // 'demo' = 10-20s, 'real' = 90-150s

export interface ResponseRecord {
  id: string;
  checkId: string;
  studentId: string;
  responseTime: number | null; // seconds, null if missed
  status: ResponseSpeedCategory;
  timestamp: number;
}

export interface StudentActiveCheck {
  id: string;
  startTime: number;
  timeoutSeconds: number;
  cueType: CueType;
}

export interface Student {
  id: string;
  name: string;
  email: string;
  currentStatus: StudentStatus;
  lastResponseStatus: 'responded' | 'delayed' | 'missed' | 'pending';
  lastResponseTime: number | null; // seconds
  attentionScore: number; // 0 - 100 (interaction indicator)
  responseCount: number;
  missedCount: number;
  totalChecks: number;
  history: ResponseRecord[];
  // Independent student attention verification scheduling:
  nextCheckTimestamp: number;
  activeCheck: StudentActiveCheck | null;
}

export interface AttentionCheck {
  id: string;
  sessionId: string;
  timestamp: number;
  cueType: CueType;
  timeoutSeconds: number;
  active: boolean;
  totalStudents: number;
  respondedCount: number;
  missedCount: number;
  averageResponseTime: number;
}

export interface ClassroomMessage {
  id: string;
  sender: string;
  role: 'teacher' | 'student';
  text: string;
  timestamp: number;
}

export interface Session {
  id: string;
  title: string;
  courseCode: string;
  teacherName: string;
  startTime: number;
  isActive: boolean;
  scheduleMode: VerificationScheduleMode; // 'demo' (10-20s) | 'real' (90-150s)
  autoCheckEnabled: boolean;
  cueType: CueType;
  checksCompleted: number;
}

export type AppView =
  | 'home'
  | 'classroom'
  | 'teacher'
  | 'student'
  | 'live-demo'
  | 'how-it-works'
  | 'privacy'
  | 'about';
