import { VerificationScheduleMode } from '../types';

/**
 * Returns a randomized millisecond interval for an individual student.
 * - Demo Mode: 10 to 20 seconds (10,000ms - 20,000ms)
 * - Real Mode: 90 to 150 seconds (90,000ms - 150,000ms) ~ 2 minute target
 */
export function generateNextCheckDelay(mode: VerificationScheduleMode): number {
  if (mode === 'demo') {
    // 10 to 20 seconds with float jitter
    const seconds = 10 + Math.random() * 10;
    return Math.round(seconds * 1000);
  } else {
    // 90 to 150 seconds (1.5 to 2.5 minutes) with float jitter
    const seconds = 90 + Math.random() * 60;
    return Math.round(seconds * 1000);
  }
}

/**
 * Formats countdown until next check in a human-friendly string
 */
export function formatCountdown(targetTimestamp: number, now: number = Date.now()): string {
  const diffSec = Math.round((targetTimestamp - now) / 1000);

  if (diffSec <= 0) {
    return 'Cue Imminent';
  }
  if (diffSec < 60) {
    return `in ${diffSec}s`;
  }

  const mins = Math.floor(diffSec / 60);
  const secs = diffSec % 60;
  return `in ${mins}m ${secs.toString().padStart(2, '0')}s`;
}

/**
 * Formats a timestamp into HH:MM:SS for precise audit logs
 */
export function formatTimeOfDay(timestamp: number): string {
  return new Date(timestamp).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}
