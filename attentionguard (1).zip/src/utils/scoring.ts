import { ResponseSpeedCategory, StudentStatus } from '../types';

export interface ScoreBreakdown {
  score: number; // 0 - 100
  status: StudentStatus;
  statusLabel: string;
  speedCategory: ResponseSpeedCategory;
  participationRate: number; // percentage
  avgSpeed: number; // seconds
}

/**
 * Categorizes response latency
 */
export function categorizeResponseTime(seconds: number | null): ResponseSpeedCategory {
  if (seconds === null) return 'missed';
  if (seconds <= 2.0) return 'quick';
  if (seconds <= 5.0) return 'normal';
  return 'delayed';
}

/**
 * Calculates a points value (0 - 100) for a single interaction
 */
export function getSingleInteractionPoints(seconds: number | null): number {
  if (seconds === null) return 0;
  if (seconds <= 1.0) return 100;
  if (seconds <= 2.0) return Math.round(95 - (seconds - 1.0) * 10); // 95 - 85
  if (seconds <= 5.0) return Math.round(85 - ((seconds - 2.0) / 3.0) * 20); // 85 - 65
  if (seconds <= 10.0) return Math.round(60 - ((seconds - 5.0) / 5.0) * 30); // 60 - 30
  return 20;
}

/**
 * Calculates overall student attention score based on all checks
 */
export function calculateStudentScore(
  history: { responseTime: number | null; status: ResponseSpeedCategory }[],
  defaultScore: number = 88
): { score: number; status: StudentStatus; statusLabel: string; avgTime: number } {
  if (!history || history.length === 0) {
    return {
      score: defaultScore,
      status: defaultScore >= 85 ? 'attentive' : 'active',
      statusLabel: defaultScore >= 85 ? 'Attentive' : 'Active',
      avgTime: 1.6,
    };
  }

  // Weight recent checks slightly higher (decay factor)
  let weightedPoints = 0;
  let totalWeights = 0;
  let validTimeSum = 0;
  let validTimeCount = 0;
  let respondedCount = 0;

  history.forEach((rec, idx) => {
    // Newer events have higher weight
    const recencyWeight = 1 + (idx / Math.max(history.length, 1)) * 0.5;
    const pts = getSingleInteractionPoints(rec.responseTime);

    if (rec.responseTime !== null) {
      validTimeSum += rec.responseTime;
      validTimeCount++;
      respondedCount++;
    }

    weightedPoints += pts * recencyWeight;
    totalWeights += recencyWeight;
  });

  const rawScore = totalWeights > 0 ? Math.round(weightedPoints / totalWeights) : defaultScore;
  const clampedScore = Math.max(10, Math.min(100, rawScore));

  const avgTime = validTimeCount > 0 ? Number((validTimeSum / validTimeCount).toFixed(1)) : 0;

  let status: StudentStatus = 'needs_attention';
  let statusLabel = 'Needs Attention Check';

  if (clampedScore >= 85) {
    status = 'attentive';
    statusLabel = 'Attentive';
  } else if (clampedScore >= 70) {
    status = 'active';
    statusLabel = 'Active';
  }

  return {
    score: clampedScore,
    status,
    statusLabel,
    avgTime,
  };
}

export const SCORING_EXPLANATION = {
  quick: {
    label: 'Strong Response',
    range: '≤ 2.0s',
    points: '85 - 100 pts',
    description: 'Immediate acknowledgment of audio cue, reflecting active presence.',
  },
  normal: {
    label: 'Normal Response',
    range: '2.1s - 5.0s',
    points: '65 - 84 pts',
    description: 'Prompt response while taking lecture notes or reading slides.',
  },
  delayed: {
    label: 'Delayed Response',
    range: '5.1s - 10.0s',
    points: '30 - 64 pts',
    description: 'Slower response; student may have looked away or switched tabs.',
  },
  missed: {
    label: 'Response Missed',
    range: '> 10.0s (Timeout)',
    points: '0 pts',
    description: 'Audio prompt expired with no keypress or click detected.',
  },
};
