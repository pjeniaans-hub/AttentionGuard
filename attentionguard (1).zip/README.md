# AttentionGuard — Privacy-Friendly Attention Verification System

> **A non-camera-based, audio-driven Attention Verification System for online classrooms and remote meetings.**

AttentionGuard verifies student engagement through randomized, pleasant harmonic audio micro-interactions rather than invasive webcams, facial recognition, eye tracking, or continuous video monitoring.

---

## 🚀 Quick Start (VS Code / Local Machine)

### Prerequisites
- **Node.js** (v18.0.0 or higher recommended, Node 20+ supported)
- **npm** (v9+ or bun / pnpm / yarn)

### Installation & Run

1. **Clone or Open Folder in VS Code:**
   ```bash
   cd attentionguard
   code .
   ```

2. **Install Dependencies:**
   ```bash
   npm install
   ```

3. **Start Development Server:**
   ```bash
   npm run dev
   ```

4. **Open in Browser:**
   Open [http://localhost:3000](http://localhost:3000) (or the port indicated in your terminal).

---

## 🛠 Project Structure

```
attentionguard/
├── index.html                     # HTML5 entry with fonts & meta
├── package.json                   # Dependencies & npm scripts
├── tsconfig.json                  # TypeScript compiler settings
├── vite.config.ts                 # Vite + Tailwind v4 + React config
├── public/
│   └── favicon.svg                # Application favicon
├── src/
│   ├── main.tsx                   # React 19 root bootstrap
│   ├── App.tsx                    # Main layout and view router
│   ├── index.css                  # Tailwind CSS v4 & theme variables
│   ├── types/
│   │   └── index.ts               # Core TypeScript data models
│   ├── utils/
│   │   ├── audio.ts               # Web Audio API harmonic chime synthesizer
│   │   └── scoring.ts             # Transparent latency-to-score calculation
│   ├── data/
│   │   └── mockData.ts            # Realistic student roster & initial sessions
│   ├── context/
│   │   └── SessionContext.tsx     # Centralized reactive classroom & audio state
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Navbar.tsx         # 3-zone header conforming to UI constitution
│   │   │   └── Footer.tsx         # Clean privacy & attribution footer
│   │   ├── home/
│   │   │   ├── HeroSection.tsx    # "Are They Really Listening?" hero + visuals
│   │   │   ├── ProcessFlow.tsx    # 4-step interactive flow
│   │   │   └── FeatureCards.tsx   # 6 core pillars of non-camera presence
│   │   ├── teacher/
│   │   │   └── TeacherDashboard.tsx # Teacher Oversight Console with live charts
│   │   ├── student/
│   │   │   └── StudentView.tsx    # Distraction-free student endpoint & prompt
│   │   ├── demo/
│   │   │   └── LiveDemoPage.tsx   # Hackathon split-screen sandbox
│   │   ├── privacy/
│   │   │   └── PrivacyPage.tsx    # Zero-camera architecture & comparison table
│   │   ├── howitworks/
│   │   │   └── HowItWorksPage.tsx # Algorithm breakdown & latency simulator
│   │   └── about/
│   │       └── AboutPage.tsx      # Origin story, digital equity, & tech stack
```

---

## ⚙️ Available Scripts

- `npm run dev`: Runs Vite dev server at port 3000
- `npm run build`: Compiles production assets into `dist/`
- `npm run preview`: Previews production build locally
- `npm run lint`: Runs TypeScript compiler type-check (`tsc --noEmit`)

---

## 🔒 Privacy & Architecture Highlights

- **Zero Camera Access:** Does not request camera permissions or transmit video.
- **Zero Facial / Eye Tracking:** 100% biometric-free.
- **Web Audio API Engine:** Synthesizes tones directly in browser memory without external mp3s.
- **Auditable & Respectful:** Uses neutral statuses like *"Attentive"*, *"Active"*, *"Needs attention check"*, and *"Did not respond"*.

---

*AttentionGuard — Verify participation. Respect privacy.*
